import { useState, useEffect } from "react"
import { v4 as uuidv4 } from "uuid"
import Sidebar, { type Page } from "./components/Sidebar"
import ChatInput from "./components/ChatInput"
import ChartRenderer from "./components/ChartRenderer"
import ChatHistory from "./components/ChatHistory"
import { sendQuery, getHealth, pinChart, getPinnedCharts, unpinChart } from "./services/api"
import type { QueryResponse, HealthResponse, PinnedChart } from "./types"
import SettingsPage from "./components/SettingsPage"
import MapView from "./components/MapView"
import AdminPanel from "./components/AdminPanel"

export default function App() {
  const [page, setPage] = useState<Page>("chat")
  const [results, setResults] = useState<QueryResponse[]>([])
  const [loading, setLoading] = useState(false)
  const [health, setHealth] = useState<HealthResponse | null>(null)
  const [conversationId] = useState(uuidv4())
  const [darkMode, setDarkMode] = useState(true)
  const [pinnedCharts, setPinnedCharts] = useState<PinnedChart[]>([])

  useEffect(() => {
    getHealth().then(setHealth).catch(() => {})
  }, [])

  useEffect(() => {
    if (page === "dashboard") {
      getPinnedCharts().then(setPinnedCharts).catch(() => {})
    }
  }, [page])

  useEffect(() => {
    if (darkMode) {
      document.body.classList.remove("light-theme")
    } else {
      document.body.classList.add("light-theme")
    }
  }, [darkMode])

  const handleQuery = async (query: string) => {
    setLoading(true)
    try {
      const result = await sendQuery(query, conversationId)
      setResults(prev => [result, ...prev])
    } catch (err: any) {
      setResults(prev => [{
        query,
        sql_generated: "",
        chart_type: "error",
        chart_config: {},
        data: [],
        error: err.message || "Failed to connect to backend",
        response_time_ms: 0,
      }, ...prev])
    }
    setLoading(false)
  }

  const handlePin = (result: QueryResponse) => {
    pinChart(
      result.chart_config.title || result.query,
      result.sql_generated,
      result.chart_type,
      result.chart_config
    ).then(() => {
      if (page === "dashboard") getPinnedCharts().then(setPinnedCharts)
    }).catch(() => {})
  }

  const handleUpdateResult = (index: number, updated: QueryResponse) => {
    setResults(prev => prev.map((r, i) => i === index ? updated : r))
  }

  const handleUnpin = (id: number) => {
    unpinChart(id).then(() => {
      setPinnedCharts(prev => prev.filter(c => c.id !== id))
    }).catch(() => {})
  }

  const handleRefreshDashboard = () => {
    getPinnedCharts().then(setPinnedCharts).catch(() => {})
  }

  const bg = darkMode ? "#000" : "#fff"
  const textColor = darkMode ? "#e2e8f0" : "#1a1a1a"
  const subtleColor = darkMode ? "#555" : "#999"
  const borderColor = darkMode ? "#1a1a1a" : "#e0e0e0"
  const cardBg = darkMode ? "#0a0a0a" : "#fafafa"

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: bg }}>
      <Sidebar currentPage={page} onNavigate={setPage} darkMode={darkMode} />

      <div style={{ flex: 1, padding: "20px 24px", maxWidth: 1000, overflow: "auto" }}>

        {/* ── HEADER ── */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <h1 style={{ margin: 0, fontSize: 20, color: textColor }}>
            {page === "dashboard" ? "Dashboard" : page === "chat" ? "Chat" : page === "map" ? "Map" : page === "admin" ? "Admin" : "Settings"}
          </h1>
          {health && (
            <span style={{ color: subtleColor, fontSize: 12 }}>
              {health.total_events.toLocaleString()} events | {health.model}
            </span>
          )}
        </div>

        {/* ── DASHBOARD PAGE ── */}
        {page === "dashboard" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <p style={{ color: subtleColor, margin: 0 }}>
                {pinnedCharts.length === 0 ? "No pinned charts yet. Ask questions in Chat and pin the charts you like." : `${pinnedCharts.length} pinned chart${pinnedCharts.length > 1 ? "s" : ""}`}
              </p>
              {pinnedCharts.length > 0 && (
                <button
                  onClick={handleRefreshDashboard}
                  style={{ background: "#3b82f6", border: "none", color: "#fff", padding: "6px 14px", borderRadius: 4, cursor: "pointer", fontSize: 13 }}
                >
                  Refresh All
                </button>
              )}
            </div>

            {pinnedCharts.map(chart => (
              <div key={chart.id} style={{ marginBottom: 16 }}>
                <ChartRenderer
                  result={{
                    query: chart.title,
                    sql_generated: chart.sql_query,
                    chart_type: chart.chart_type,
                    chart_config: chart.chart_config,
                    data: chart.data,
                    error: null,
                    response_time_ms: 0,
                  }}
                />
                <button
                  onClick={() => handleUnpin(chart.id)}
                  style={{ background: "none", border: `1px solid ${borderColor}`, color: "#ef4444", padding: "2px 10px", borderRadius: 4, cursor: "pointer", fontSize: 12, marginTop: 4 }}
                >
                  Unpin
                </button>
              </div>
            ))}
          </div>
        )}

        {/* ── CHAT PAGE ── */}
        {page === "chat" && (
          <div>
            <ChatInput onSubmit={handleQuery} loading={loading} />
            <ChatHistory results={results} onPin={handlePin} onUpdate={handleUpdateResult} darkMode={darkMode} />
          </div>
        )}
        {page === "map" && (
          <MapView darkMode={darkMode} />
        )}
        {page === "admin" && (
          <AdminPanel darkMode={darkMode} />
        )}
        {/* ── SETTINGS PAGE (placeholder for now) ── */}
        {page === "settings" && (
          <SettingsPage darkMode={darkMode} onToggleTheme={setDarkMode} />
        )}
      </div>
    </div>
  )
}