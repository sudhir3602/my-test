import axios from "axios"
import type { QueryResponse, HealthResponse, StatsResponse, PinnedChart } from "../types"

const api = axios.create({ baseURL: "/api" })

export async function sendQuery(query: string, conversationId?: string): Promise<QueryResponse> {
  const res = await api.post("/query", { query, conversation_id: conversationId })
  return res.data
}

export async function getHealth(): Promise<HealthResponse> {
  const res = await api.get("/health")
  return res.data
}

export async function getStats(): Promise<StatsResponse> {
  const res = await api.get("/stats")
  return res.data
}

export async function pinChart(title: string, sqlQuery: string, chartType: string, chartConfig: Record<string, any>): Promise<void> {
  await api.post("/pin", { title, sql_query: sqlQuery, chart_type: chartType, chart_config: chartConfig })
}

export async function getPinnedCharts(): Promise<PinnedChart[]> {
  const res = await api.get("/pinned")
  return res.data
}

export async function unpinChart(id: number): Promise<void> {
  await api.delete(`/pin/${id}`)
}

export async function getActorConfig(): Promise<Record<string, any>> {
  const res = await api.get("/settings/actor-config")
  return res.data
}

export async function updateActorConfig(config: Record<string, any>): Promise<void> {
  await api.put("/settings/actor-config", config)
}