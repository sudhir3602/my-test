export interface QueryResponse {
  query: string
  sql_generated: string
  chart_type: string
  chart_config: {
    title?: string
    x_label?: string
    y_label?: string
    columns?: string[]
  }
  data: Record<string, any>[]
  error: string | null
  response_time_ms: number
}

export interface HealthResponse {
  status: string
  model: string
  database_path: string
  total_events: number
  latest_event_date: string | null
}

export interface StatsResponse {
  total_events: number
  total_actors: number
  total_locations: number
  date_range: { earliest: string; latest: string }
  top_actors: { name: string; count: number }[]
  top_locations: { name: string; count: number }[]
  events_by_bucket: { bucket: string; count: number }[]
}

export interface PinnedChart {
  id: number
  title: string
  sql_query: string
  chart_type: string
  chart_config: Record<string, any>
  pinned_at: string
  data: Record<string, any>[]
}