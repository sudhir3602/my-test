import { useState } from "react"
import {
  LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, ScatterChart, Scatter, AreaChart, Area
} from "recharts"
import type { QueryResponse } from "../types"
import axios from "axios"

interface Props {
  result: QueryResponse
  onPin?: () => void
  onUpdate?: (updated: QueryResponse) => void
}

export default function ChartRenderer({ result, onPin, onUpdate }: Props) {
  const [showSql, setShowSql] = useState(false)
  const [editing, setEditing] = useState(false)
  const [editSql, setEditSql] = useState(result.sql_generated)
  const [running, setRunning] = useState(false)
  const { chart_type, chart_config, data, sql_generated, error, response_time_ms } = result

  const handleRunEdited = async () => {
    setRunning(true)
    try {
      const res = await axios.post("/api/sql", { query: editSql })
      if (res.data.error) {
        if (onUpdate) onUpdate({ ...result, data: [], error: res.data.error, sql_generated: editSql })
      } else {
        if (onUpdate) onUpdate({
          ...result,
          data: res.data.data,
          sql_generated: editSql,
          error: null,
          chart_config: { ...chart_config, columns: res.data.columns },
        })
      }
      setEditing(false)
    } catch (err: any) {
      if (onUpdate) onUpdate({ ...result, error: err.message, sql_generated: editSql })
    }
    setRunning(false)
  }

  if (error) {
    return (
      <div style={{ background: "#1a0000", border: "1px solid #cc0000", borderRadius: 8, padding: 16, margin: "8px 0" }}>
        <p style={{ color: "#ff4444", margin: "0 0 8px" }}>Error: {error}</p>
        {sql_generated && (
          <>
            <pre style={{ color: "#888", fontSize: 12, whiteSpace: "pre-wrap", margin: "0 0 8px" }}>{sql_generated}</pre>
            {!editing && (
              <button onClick={() => { setEditing(true); setEditSql(sql_generated); setShowSql(true) }}
                style={{ background: "#3b82f6", border: "none", color: "#fff", padding: "4px 12px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
                Edit SQL
              </button>
            )}
          </>
        )}
        {editing && (
          <div style={{ marginTop: 8 }}>
            <textarea value={editSql} onChange={e => setEditSql(e.target.value)}
              style={{ width: "100%", minHeight: 100, background: "#050505", color: "#7dd3fc", border: "1px solid #333", borderRadius: 4, padding: 8, fontSize: 12, fontFamily: "monospace", resize: "vertical" }} />
            <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
              <button onClick={handleRunEdited} disabled={running}
                style={{ background: "#22c55e", border: "none", color: "#fff", padding: "4px 14px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
                {running ? "Running..." : "Run"}
              </button>
              <button onClick={() => setEditing(false)}
                style={{ background: "none", border: "1px solid #333", color: "#888", padding: "4px 14px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    )
  }

  if (!data || data.length === 0) {
    return <p style={{ color: "#888" }}>No data returned.</p>
  }

  const columns = Object.keys(data[0])
  const xKey = columns[0]
  const yKeys = columns.slice(1)
  const colours = ["#3b82f6", "#ef4444", "#22c55e", "#f59e0b", "#a855f7"]

  const xLabel = chart_config.x_label || xKey
  const yLabel = chart_config.y_label || yKeys[0] || "Value"

  const renderChart = () => {
    switch (chart_type) {
      case "line":
        return (
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis dataKey={xKey} stroke="#888" tick={{ fontSize: 11 }} angle={-45} textAnchor="end" height={80} label={{ value: xLabel, position: "insideBottom", offset: -5, fill: "#888", fontSize: 12 }} />
              <YAxis stroke="#888" tick={{ fontSize: 11 }} label={{ value: yLabel, angle: -90, position: "insideLeft", fill: "#888", fontSize: 12 }} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #333" }} />
              {yKeys.map((key, i) => (
                <Line key={key} type="monotone" dataKey={key} stroke={colours[i % colours.length]} dot={false} strokeWidth={2} name={key} />
              ))}
            </LineChart>
          </ResponsiveContainer>
        )

      case "bar":
        return (
          <ResponsiveContainer width="100%" height={350}>
            <BarChart data={data.slice(0, 20)}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis dataKey={xKey} stroke="#888" tick={{ fontSize: 11 }} angle={-45} textAnchor="end" height={100} label={{ value: xLabel, position: "insideBottom", offset: -5, fill: "#888", fontSize: 12 }} />
              <YAxis stroke="#888" tick={{ fontSize: 11 }} label={{ value: yLabel, angle: -90, position: "insideLeft", fill: "#888", fontSize: 12 }} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #333" }} />
              {yKeys.map((key, i) => (
                <Bar key={key} dataKey={key} fill={colours[i % colours.length]} name={key} />
              ))}
            </BarChart>
          </ResponsiveContainer>
        )

      case "scatter":
        return (
          <ResponsiveContainer width="100%" height={350}>
            <ScatterChart>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis dataKey={xKey} stroke="#888" name={xKey} tick={{ fontSize: 11 }} label={{ value: xLabel, position: "insideBottom", offset: -5, fill: "#888", fontSize: 12 }} />
              <YAxis dataKey={yKeys[0]} stroke="#888" name={yKeys[0]} tick={{ fontSize: 11 }} label={{ value: yLabel, angle: -90, position: "insideLeft", fill: "#888", fontSize: 12 }} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #333" }} />
              <Scatter data={data} fill="#3b82f6" />
            </ScatterChart>
          </ResponsiveContainer>
        )

      case "stacked_area":
        return (
          <ResponsiveContainer width="100%" height={350}>
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#222" />
              <XAxis dataKey={xKey} stroke="#888" tick={{ fontSize: 11 }} />
              <YAxis stroke="#888" tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "#111", border: "1px solid #333" }} />
              {yKeys.map((key, i) => (
                <Area key={key} type="monotone" dataKey={key} stackId="1" fill={colours[i % colours.length]} stroke={colours[i % colours.length]} name={key} />
              ))}
            </AreaChart>
          </ResponsiveContainer>
        )

      case "table":
      default:
        return (
          <div style={{ overflowX: "auto", maxHeight: 400 }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
              <thead>
                <tr>
                  {columns.map(col => (
                    <th key={col} style={{ textAlign: "left", padding: "8px 12px", borderBottom: "1px solid #333", color: "#aaa" }}>{col}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {data.slice(0, 100).map((row, i) => (
                  <tr key={i} style={{ borderBottom: "1px solid #1a1a1a" }}>
                    {columns.map(col => (
                      <td key={col} style={{ padding: "6px 12px", color: "#ccc" }}>{row[col] ?? "null"}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            {data.length > 100 && <p style={{ color: "#888", fontSize: 12, marginTop: 8 }}>Showing 100 of {data.length} rows</p>}
          </div>
        )
    }
  }

  return (
    <div style={{ background: "#0a0a0a", border: "1px solid #1a1a1a", borderRadius: 8, padding: 16, margin: "8px 0" }}>
      {chart_config.title && <h3 style={{ margin: "0 0 12px", fontSize: 16, color: "#e2e8f0" }}>{chart_config.title}</h3>}

      {renderChart()}

      <div style={{ display: "flex", gap: 12, marginTop: 12, alignItems: "center", flexWrap: "wrap" }}>
        <span style={{ color: "#555", fontSize: 12 }}>{response_time_ms}ms | {data.length} rows | {chart_type}</span>
        <button onClick={() => { setShowSql(!showSql); setEditSql(sql_generated) }}
          style={{ background: "none", border: "1px solid #333", color: "#888", padding: "2px 8px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
          {showSql ? "Hide SQL" : "Show SQL"}
        </button>
        {showSql && !editing && (
          <button onClick={() => setEditing(true)}
            style={{ background: "none", border: "1px solid #333", color: "#3b82f6", padding: "2px 8px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
            Edit SQL
          </button>
        )}
        {onPin && (
          <button onClick={onPin}
            style={{ background: "none", border: "1px solid #333", color: "#888", padding: "2px 8px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
            Pin
          </button>
        )}
      </div>

      {showSql && !editing && (
        <pre style={{ background: "#050505", color: "#7dd3fc", padding: 12, borderRadius: 4, marginTop: 8, fontSize: 12, whiteSpace: "pre-wrap" }}>
          {sql_generated}
        </pre>
      )}

      {editing && (
        <div style={{ marginTop: 8 }}>
          <textarea value={editSql} onChange={e => setEditSql(e.target.value)}
            style={{ width: "100%", minHeight: 100, background: "#050505", color: "#7dd3fc", border: "1px solid #333", borderRadius: 4, padding: 8, fontSize: 12, fontFamily: "monospace", resize: "vertical" }} />
          <div style={{ display: "flex", gap: 8, marginTop: 6 }}>
            <button onClick={handleRunEdited} disabled={running}
              style={{ background: "#22c55e", border: "none", color: "#fff", padding: "4px 14px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
              {running ? "Running..." : "Run Edited SQL"}
            </button>
            <button onClick={() => setEditing(false)}
              style={{ background: "none", border: "1px solid #333", color: "#888", padding: "4px 14px", borderRadius: 4, cursor: "pointer", fontSize: 12 }}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )
}