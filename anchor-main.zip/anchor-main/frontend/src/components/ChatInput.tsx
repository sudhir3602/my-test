import { useState } from "react"

interface Props {
  onSubmit: (query: string) => void
  loading: boolean
}

export default function ChatInput({ onSubmit, loading }: Props) {
  const [input, setInput] = useState("")

  const handleSubmit = () => {
    if (!input.trim() || loading) return
    onSubmit(input.trim())
    setInput("")
  }

  return (
    <div style={{ display: "flex", gap: 8, padding: "12px 0" }}>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        onKeyDown={e => e.key === "Enter" && handleSubmit()}
        placeholder="Ask a question about the Sudan conflict..."
        disabled={loading}
        style={{
          flex: 1, padding: "10px 14px", background: "#111", border: "1px solid #333",
          borderRadius: 6, color: "#e2e8f0", fontSize: 14, outline: "none",
        }}
      />
      <button
        onClick={handleSubmit}
        disabled={loading}
        style={{
          padding: "10px 20px", background: loading ? "#222" : "#3b82f6",
          border: "none", borderRadius: 6, color: "#fff", cursor: loading ? "wait" : "pointer", fontSize: 14,
        }}
      >
        {loading ? "Thinking..." : "Ask"}
      </button>
    </div>
  )
}