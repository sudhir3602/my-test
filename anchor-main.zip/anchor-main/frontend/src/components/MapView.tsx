import { useState, useEffect } from "react"
import { MapContainer, TileLayer, CircleMarker, Popup } from "react-leaflet"
import type { StatsResponse } from "../types"
import { getStats } from "../services/api"
import axios from "axios"

interface Props {
  darkMode: boolean
}

interface MapEvent {
  name: string
  lat: number
  lng: number
  count: number
}

export default function MapView({ darkMode }: Props) {
  const [events, setEvents] = useState<MapEvent[]>([])
  const [loading, setLoading] = useState(true)

  const subtleColor = darkMode ? "#555" : "#999"

  useEffect(() => {
    axios.post("/api/sql", {
      query: "SELECT action_geo_name, action_geo_lat, action_geo_long, COUNT(*) as count FROM events WHERE action_geo_lat IS NOT NULL AND action_geo_long IS NOT NULL AND action_geo_name IS NOT NULL GROUP BY action_geo_name, action_geo_lat, action_geo_long ORDER BY count DESC LIMIT 200"
    }).then(res => {
      const data = res.data.data || []
      const mapped = data
        .filter((r: any) => r.action_geo_lat && r.action_geo_long && r.action_geo_name)
        .filter((r: any) => !(/^[A-Z]{2}\d*$/.test(r.action_geo_name)))
        .map((r: any) => ({
          name: r.action_geo_name,
          lat: r.action_geo_lat,
          lng: r.action_geo_long,
          count: r.count || r["COUNT(*)"] || 1,
        }))
      setEvents(mapped)
      setLoading(false)
    }).catch(() => setLoading(false))
  }, [])

  if (loading) return <p style={{ color: subtleColor }}>Loading map data...</p>
  if (events.length === 0) return <p style={{ color: subtleColor }}>No location data available.</p>

  const maxCount = Math.max(...events.map(e => e.count))

  return (
    <div style={{ borderRadius: 8, overflow: "hidden", border: `1px solid ${darkMode ? "#1a1a1a" : "#e0e0e0"}` }}>
      <MapContainer
        center={[15.5, 32.5]}
        zoom={5}
        style={{ height: "calc(100vh - 120px)", width: "100%" }}
      >
        <TileLayer
          url={darkMode
            ? "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            : "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          }
          attribution='&copy; OpenStreetMap contributors'
        />
        {events.map((event, i) => {
          const radius = Math.max(4, Math.min(25, (event.count / maxCount) * 25))
          return (
            <CircleMarker
              key={i}
              center={[event.lat, event.lng]}
              radius={radius}
              fillColor="#ef4444"
              fillOpacity={0.6}
              stroke={true}
              color="#ef4444"
              weight={1}
            >
              <Popup>
                <div style={{ color: "#000" }}>
                  <strong>{event.name}</strong><br />
                  {event.count} events
                </div>
              </Popup>
            </CircleMarker>
          )
        })}
      </MapContainer>
    </div>
  )
}