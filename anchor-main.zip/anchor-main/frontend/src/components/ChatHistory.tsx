import ChartRenderer from "./ChartRenderer"
import type { QueryResponse } from "../types"

interface Props {
  results: QueryResponse[]
  onPin: (result: QueryResponse) => void
  onUpdate: (index: number, updated: QueryResponse) => void
  darkMode: boolean
}

export default function ChatHistory({ results, onPin, onUpdate, darkMode }: Props) {
  const subtleColor = darkMode ? "#555" : "#999"

  if (results.length === 0) {
    return (
      <div style={{ textAlign: "center", padding: "60px 0", color: subtleColor }}>
        <p style={{ fontSize: 16, marginBottom: 4 }}>No queries yet</p>
        <p style={{ fontSize: 13 }}>Try: "How has the number of events changed week by week?"</p>
      </div>
    )
  }

  return (
    <div>
      {results.map((result, i) => (
        <div key={i} style={{ marginBottom: 20 }}>
          <p style={{ color: subtleColor, fontSize: 13, margin: "8px 0 4px" }}>Q: {result.query}</p>
          <ChartRenderer
            result={result}
            onPin={() => onPin(result)}
            onUpdate={(updated) => onUpdate(i, updated)}
          />
        </div>
      ))}
    </div>
  )
}