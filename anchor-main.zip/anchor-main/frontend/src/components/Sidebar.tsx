import { useState } from "react"

export type Page = "dashboard" | "chat" | "map" | "admin" | "settings"

interface Props {
  currentPage: Page
  onNavigate: (page: Page) => void
  darkMode: boolean
}

export default function Sidebar({ currentPage, onNavigate, darkMode }: Props) {
  const [collapsed, setCollapsed] = useState(false)

  const bg = darkMode ? "#0a0a0a" : "#f5f5f5"
  const borderColor = darkMode ? "#1a1a1a" : "#e0e0e0"
  const textColor = darkMode ? "#e2e8f0" : "#1a1a1a"
  const mutedColor = darkMode ? "#888" : "#666"
  const activeColor = "#3b82f6"

  const navItems: { id: Page; label: string; icon: string }[] = [
    { id: "dashboard", label: "Dashboard", icon: "📊" },
    { id: "chat", label: "Chat", icon: "💬" },
    { id: "map", label: "Map", icon: "🗺️" },
    { id: "admin", label: "Admin", icon: "📈" },
    { id: "settings", label: "Settings", icon: "⚙️" },
  ]

  return (
    <div style={{
      width: collapsed ? 50 : 200,
      minHeight: "100vh",
      background: bg,
      borderRight: `1px solid ${borderColor}`,
      display: "flex",
      flexDirection: "column",
      transition: "width 0.2s",
    }}>
      <div style={{
        padding: collapsed ? "16px 8px" : "16px",
        borderBottom: `1px solid ${borderColor}`,
        display: "flex",
        alignItems: "center",
        justifyContent: collapsed ? "center" : "space-between",
      }}>
        {!collapsed && <span style={{ fontWeight: 700, fontSize: 18, color: textColor }}>Anchor</span>}
        <button
          onClick={() => setCollapsed(!collapsed)}
          style={{ background: "none", border: "none", color: mutedColor, cursor: "pointer", fontSize: 16 }}
        >
          {collapsed ? "▶" : "◀"}
        </button>
      </div>

      <nav style={{ flex: 1, padding: "8px 0" }}>
        {navItems.map(item => {
          const isActive = currentPage === item.id
          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: 10,
                width: "100%",
                padding: collapsed ? "10px 0" : "10px 16px",
                justifyContent: collapsed ? "center" : "flex-start",
                background: isActive ? (darkMode ? "#1a1a2e" : "#e8f0fe") : "transparent",
                border: "none",
                borderLeft: isActive ? `3px solid ${activeColor}` : "3px solid transparent",
                color: isActive ? activeColor : mutedColor,
                cursor: "pointer",
                fontSize: 14,
                textAlign: "left",
              }}
            >
              <span>{item.icon}</span>
              {!collapsed && <span>{item.label}</span>}
            </button>
          )
        })}
      </nav>
    </div>
  )
}