import { useState, useEffect } from "react"
import { getActorConfig, updateActorConfig } from "../services/api"
import axios from "axios"
interface Props {
  darkMode: boolean
  onToggleTheme: (dark: boolean) => void
}

export default function SettingsPage({ darkMode, onToggleTheme }: Props) {
  const [config, setConfig] = useState<Record<string, any> | null>(null)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [saveMessage, setSaveMessage] = useState("")
  const [newPattern, setNewPattern] = useState("")
  const [newCanonical, setNewCanonical] = useState("")
  const [newLocation, setNewLocation] = useState("")
  const [mapSearch, setMapSearch] = useState("")
  const [locSearch, setLocSearch] = useState("")
  const [prompt, setPrompt] = useState("")
  const [promptLoading, setPromptLoading] = useState(false)
  const [promptMessage, setPromptMessage] = useState("")
  const [models, setModels] = useState<string[]>([])
  const [currentModel, setCurrentModel] = useState("")
  const [modelMessage, setModelMessage] = useState("")
  const [backfillMessage, setBackfillMessage] = useState("")
  const [backfilling, setBackfilling] = useState(false)
  const [updateInterval, setUpdateInterval] = useState(15)

  const textColor = darkMode ? "#e2e8f0" : "#1a1a1a"
  const subtleColor = darkMode ? "#555" : "#999"
  const borderColor = darkMode ? "#1a1a1a" : "#e0e0e0"
  const cardBg = darkMode ? "#0a0a0a" : "#fafafa"
  const inputBg = darkMode ? "#111" : "#fff"
  const dangerColor = "#ef4444"

  useEffect(() => {
    getActorConfig()
      .then(data => { setConfig(data); setLoading(false) })
      .catch(() => setLoading(false))

    axios.get("/api/settings/prompt").then(res => setPrompt(res.data.prompt)).catch(() => {})
    axios.get("/api/settings/models").then(res => {
      setModels(res.data.available || [])
      setCurrentModel(res.data.current || "")
    }).catch(() => {})
    axios.get("/api/settings/update-interval").then(res => setUpdateInterval(res.data.minutes)).catch(() => {})
  }, [])

  const handleSave = async () => {
    if (!config) return
    setSaving(true)
    setSaveMessage("")
    try {
      await updateActorConfig(config)
      setSaveMessage("Saved. Re-run ingestion to apply changes to existing data.")
    } catch (err: any) {
      setSaveMessage("Failed to save: " + (err.message || "Unknown error"))
    }
    setSaving(false)
  }

  const addMapping = () => {
    if (!newPattern.trim() || !newCanonical.trim() || !config) return
    const updated = { ...config }
    updated.actor_name_map[newPattern.trim().toUpperCase()] = newCanonical.trim()
    setConfig(updated)
    setNewPattern("")
    setNewCanonical("")
  }

  const removeMapping = (key: string) => {
    if (!config) return
    const updated = { ...config }
    delete updated.actor_name_map[key]
    setConfig(updated)
  }

  const addLocation = () => {
    if (!newLocation.trim() || !config) return
    const updated = { ...config }
    const upper = newLocation.trim().toUpperCase()
    if (!updated.location_actors.includes(upper)) {
      updated.location_actors.push(upper)
      updated.location_actors.sort()
    }
    setConfig(updated)
    setNewLocation("")
  }

  const removeLocation = (loc: string) => {
    if (!config) return
    const updated = { ...config }
    updated.location_actors = updated.location_actors.filter((l: string) => l !== loc)
    setConfig(updated)
  }

  if (loading) return <p style={{ color: subtleColor }}>Loading config...</p>
  if (!config) return <p style={{ color: dangerColor }}>Failed to load actor config. Is the backend running?</p>

  const actorMap = config.actor_name_map || {}
  const locationActors = config.location_actors || []

  const filteredMap = Object.entries(actorMap).filter(([key, val]) => {
    if (!mapSearch) return true
    const s = mapSearch.toUpperCase()
    return key.toUpperCase().includes(s) || String(val).toUpperCase().includes(s)
  })

  const filteredLocs = locationActors.filter((loc: string) => {
    if (!locSearch) return true
    return loc.toUpperCase().includes(locSearch.toUpperCase())
  })

  return (
    <div>
      {/* Theme toggle */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor }}>Appearance</h3>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ color: subtleColor }}>Theme:</span>
          <button
            onClick={() => onToggleTheme(true)}
            style={{
              padding: "6px 14px", borderRadius: 4, cursor: "pointer", fontSize: 13,
              background: darkMode ? "#3b82f6" : "transparent",
              border: `1px solid ${darkMode ? "#3b82f6" : borderColor}`,
              color: darkMode ? "#fff" : subtleColor,
            }}
          >Dark</button>
          <button
            onClick={() => onToggleTheme(false)}
            style={{
              padding: "6px 14px", borderRadius: 4, cursor: "pointer", fontSize: 13,
              background: !darkMode ? "#3b82f6" : "transparent",
              border: `1px solid ${!darkMode ? "#3b82f6" : borderColor}`,
              color: !darkMode ? "#fff" : subtleColor,
            }}
          >Light</button>
        </div>
      </div>

      {/* Data Management */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor }}>Data Management</h3>

        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 16 }}>
          <button
            onClick={() => {
              setBackfilling(true)
              setBackfillMessage("")
              axios.post("/api/settings/backfill").then(res => {
                setBackfillMessage(res.data.message)
              }).catch(() => setBackfillMessage("Failed to start backfill"))
              .finally(() => setBackfilling(false))
            }}
            disabled={backfilling}
            style={{
              padding: "8px 18px", borderRadius: 4, cursor: backfilling ? "wait" : "pointer", fontSize: 13,
              background: backfilling ? "#222" : "#3b82f6", border: "none", color: "#fff",
            }}
          >{backfilling ? "Starting..." : "Backfill to Now"}</button>
          {backfillMessage && <span style={{ color: "#22c55e", fontSize: 12 }}>{backfillMessage}</span>}
        </div>

        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <label style={{ color: subtleColor, fontSize: 13 }}>Pull frequency:</label>
          <select
            value={updateInterval}
            onChange={e => {
              const val = Number(e.target.value)
              setUpdateInterval(val)
              axios.put("/api/settings/update-interval", { minutes: val }).catch(() => {})
            }}
            style={{
              padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`,
              borderRadius: 4, color: textColor, fontSize: 13, cursor: "pointer",
            }}
          >
            <option value={15}>Every 15 minutes</option>
            <option value={30}>Every 30 minutes</option>
            <option value={60}>Every hour</option>
            <option value={360}>Every 6 hours</option>
            <option value={720}>Every 12 hours</option>
            <option value={1440}>Every day</option>
            <option value={10080}>Every week</option>
            <option value={43200}>Every month</option>
          </select>
        </div>
      </div>

      {/* Model switching */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor }}>LLM Model</h3>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
          <span style={{ color: subtleColor, fontSize: 13 }}>Current: {currentModel}</span>
          {models.map(model => (
            <button
              key={model}
              onClick={() => {
                axios.put("/api/settings/model", { model }).then(() => {
                  setCurrentModel(model)
                  setModelMessage(`Switched to ${model}`)
                  setTimeout(() => setModelMessage(""), 3000)
                }).catch(() => setModelMessage("Failed to switch"))
              }}
              style={{
                padding: "4px 12px", borderRadius: 4, cursor: "pointer", fontSize: 12,
                background: model === currentModel ? "#3b82f6" : "transparent",
                border: `1px solid ${model === currentModel ? "#3b82f6" : borderColor}`,
                color: model === currentModel ? "#fff" : subtleColor,
              }}
            >{model}</button>
          ))}
        </div>
        {modelMessage && <p style={{ color: "#22c55e", fontSize: 12, marginTop: 6 }}>{modelMessage}</p>}
      </div>

      {/* System prompt editor */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor }}>System Prompt</h3>
        <p style={{ color: subtleColor, fontSize: 12, margin: "0 0 8px" }}>
          This is the full prompt sent to the LLM with every query. Edit with care.
        </p>
        <textarea
          value={prompt}
          onChange={e => setPrompt(e.target.value)}
          style={{
            width: "100%", minHeight: 300, background: inputBg, color: textColor,
            border: `1px solid ${borderColor}`, borderRadius: 4, padding: 10,
            fontSize: 12, fontFamily: "monospace", resize: "vertical",
          }}
        />
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 8 }}>
          <button
            disabled={promptLoading}
            onClick={() => {
              setPromptLoading(true)
              axios.put("/api/settings/prompt", { prompt }).then(() => {
                setPromptMessage("Prompt saved")
                setTimeout(() => setPromptMessage(""), 3000)
              }).catch(() => setPromptMessage("Failed to save"))
              .finally(() => setPromptLoading(false))
            }}
            style={{ background: "#22c55e", border: "none", color: "#fff", padding: "6px 16px", borderRadius: 4, cursor: "pointer", fontSize: 13 }}
          >{promptLoading ? "Saving..." : "Save Prompt"}</button>
          {promptMessage && <span style={{ color: "#22c55e", fontSize: 12 }}>{promptMessage}</span>}
        </div>
      </div>

      {/* Conflict info */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor }}>Conflict Configuration</h3>
        <div style={{ display: "flex", gap: 12, alignItems: "center", marginBottom: 8 }}>
          <label style={{ color: subtleColor, fontSize: 13, minWidth: 100 }}>Conflict name:</label>
          <input
            value={config.conflict_name || ""}
            onChange={e => setConfig({ ...config, conflict_name: e.target.value })}
            style={{ flex: 1, padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 13 }}
          />
        </div>
        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <label style={{ color: subtleColor, fontSize: 13, minWidth: 100 }}>Country codes:</label>
          <input
            value={(config.country_codes || []).join(", ")}
            onChange={e => setConfig({ ...config, country_codes: e.target.value.split(",").map((s: string) => s.trim()).filter(Boolean) })}
            style={{ flex: 1, padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 13 }}
          />
        </div>
      </div>

      {/* Actor name map */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <h3 style={{ margin: 0, color: textColor }}>Actor Name Mappings ({Object.keys(actorMap).length})</h3>
          <input
            value={mapSearch}
            onChange={e => setMapSearch(e.target.value)}
            placeholder="Search..."
            style={{ padding: "4px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 12, width: 160 }}
          />
        </div>

        {/* Add new mapping */}
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <input
            value={newPattern}
            onChange={e => setNewPattern(e.target.value)}
            placeholder="Pattern (e.g. GREEK)"
            style={{ flex: 1, padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 13 }}
          />
          <input
            value={newCanonical}
            onChange={e => setNewCanonical(e.target.value)}
            placeholder="Maps to (e.g. Greece)"
            onKeyDown={e => e.key === "Enter" && addMapping()}
            style={{ flex: 1, padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 13 }}
          />
          <button
            onClick={addMapping}
            style={{ padding: "6px 14px", background: "#3b82f6", border: "none", borderRadius: 4, color: "#fff", cursor: "pointer", fontSize: 13 }}
          >Add</button>
        </div>

        {/* Mapping list */}
        <div style={{ maxHeight: 300, overflow: "auto" }}>
          {filteredMap.map(([key, val]) => (
            <div key={key} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "4px 0", borderBottom: `1px solid ${borderColor}` }}>
              <span style={{ color: subtleColor, fontSize: 12, flex: 1 }}>{key}</span>
              <span style={{ color: textColor, fontSize: 12, flex: 1 }}>{String(val)}</span>
              <button
                onClick={() => removeMapping(key)}
                style={{ background: "none", border: "none", color: dangerColor, cursor: "pointer", fontSize: 12, padding: "2px 6px" }}
              >Remove</button>
            </div>
          ))}
        </div>
      </div>

      {/* Location actors */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <h3 style={{ margin: 0, color: textColor }}>Location Actors ({locationActors.length})</h3>
          <input
            value={locSearch}
            onChange={e => setLocSearch(e.target.value)}
            placeholder="Search..."
            style={{ padding: "4px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 12, width: 160 }}
          />
        </div>
        <p style={{ color: subtleColor, fontSize: 12, margin: "0 0 10px" }}>
          Location names that GDELT incorrectly labels as actors. These get tagged with [LOC] during ingestion.
        </p>

        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <input
            value={newLocation}
            onChange={e => setNewLocation(e.target.value)}
            placeholder="Location name (e.g. DAMASCUS)"
            onKeyDown={e => e.key === "Enter" && addLocation()}
            style={{ flex: 1, padding: "6px 10px", background: inputBg, border: `1px solid ${borderColor}`, borderRadius: 4, color: textColor, fontSize: 13 }}
          />
          <button
            onClick={addLocation}
            style={{ padding: "6px 14px", background: "#3b82f6", border: "none", borderRadius: 4, color: "#fff", cursor: "pointer", fontSize: 13 }}
          >Add</button>
        </div>

        <div style={{ maxHeight: 200, overflow: "auto" }}>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
            {filteredLocs.map((loc: string) => (
              <span key={loc} style={{ display: "inline-flex", alignItems: "center", gap: 4, background: darkMode ? "#111" : "#eee", padding: "3px 8px", borderRadius: 4, fontSize: 12, color: textColor }}>
                {loc}
                <button
                  onClick={() => removeLocation(loc)}
                  style={{ background: "none", border: "none", color: dangerColor, cursor: "pointer", fontSize: 12, padding: 0, lineHeight: 1 }}
                >x</button>
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Save button */}
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <button
          onClick={handleSave}
          disabled={saving}
          style={{ padding: "8px 24px", background: saving ? "#222" : "#22c55e", border: "none", borderRadius: 4, color: "#fff", cursor: saving ? "wait" : "pointer", fontSize: 14 }}
        >{saving ? "Saving..." : "Save All Changes"}</button>
        {saveMessage && <span style={{ color: saveMessage.startsWith("Failed") ? dangerColor : "#22c55e", fontSize: 13 }}>{saveMessage}</span>}
      </div>
    </div>
  )
}