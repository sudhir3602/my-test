import { useState, useEffect } from "react"
import { getStats } from "../services/api"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"
import type { StatsResponse } from "../types"

interface Props {
  darkMode: boolean
}

export default function AdminPanel({ darkMode }: Props) {
  const [stats, setStats] = useState<StatsResponse | null>(null)
  const [loading, setLoading] = useState(true)

  const textColor = darkMode ? "#e2e8f0" : "#1a1a1a"
  const subtleColor = darkMode ? "#555" : "#999"
  const borderColor = darkMode ? "#1a1a1a" : "#e0e0e0"
  const cardBg = darkMode ? "#0a0a0a" : "#fafafa"

  useEffect(() => {
    getStats().then(data => { setStats(data); setLoading(false) }).catch(() => setLoading(false))
  }, [])

  if (loading) return <p style={{ color: subtleColor }}>Loading stats...</p>
  if (!stats) return <p style={{ color: "#ef4444" }}>Failed to load stats.</p>

  const statCards = [
    { label: "Total Events", value: stats.total_events.toLocaleString() },
    { label: "Unique Actors", value: stats.total_actors.toLocaleString() },
    { label: "Unique Locations", value: stats.total_locations.toLocaleString() },
    { label: "Date Range", value: `${stats.date_range.earliest || "N/A"} to ${stats.date_range.latest || "N/A"}` },
  ]

  return (
    <div>
      {/* Stat cards */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 12, marginBottom: 24 }}>
        {statCards.map(card => (
          <div key={card.label} style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16 }}>
            <p style={{ color: subtleColor, fontSize: 12, margin: "0 0 4px" }}>{card.label}</p>
            <p style={{ color: textColor, fontSize: 20, fontWeight: 700, margin: 0 }}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Events by CAMEO bucket */}
      <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16, marginBottom: 24 }}>
        <h3 style={{ margin: "0 0 12px", color: textColor, fontSize: 15 }}>Events by Category</h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={stats.events_by_bucket} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? "#222" : "#eee"} />
            <XAxis type="number" stroke={subtleColor} tick={{ fontSize: 11 }} />
            <YAxis type="category" dataKey="bucket" width={140} stroke={subtleColor} tick={{ fontSize: 11 }} />
            <Tooltip contentStyle={{ background: darkMode ? "#111" : "#fff", border: `1px solid ${borderColor}` }} />
            <Bar dataKey="count" fill="#3b82f6" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Top actors and locations side by side */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16 }}>
          <h3 style={{ margin: "0 0 12px", color: textColor, fontSize: 15 }}>Top Actors</h3>
          {stats.top_actors.map((actor, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: `1px solid ${borderColor}` }}>
              <span style={{ color: textColor, fontSize: 13 }}>{actor.name}</span>
              <span style={{ color: subtleColor, fontSize: 13 }}>{actor.count.toLocaleString()}</span>
            </div>
          ))}
        </div>

        <div style={{ background: cardBg, border: `1px solid ${borderColor}`, borderRadius: 8, padding: 16 }}>
          <h3 style={{ margin: "0 0 12px", color: textColor, fontSize: 15 }}>Top Locations</h3>
          {stats.top_locations.map((loc, i) => (
            <div key={i} style={{ display: "flex", justifyContent: "space-between", padding: "4px 0", borderBottom: `1px solid ${borderColor}` }}>
              <span style={{ color: textColor, fontSize: 13 }}>{loc.name}</span>
              <span style={{ color: subtleColor, fontSize: 13 }}>{loc.count.toLocaleString()}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}