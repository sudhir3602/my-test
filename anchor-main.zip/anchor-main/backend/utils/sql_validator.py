"""
sql_validator.py

Security gate between the LLM and the database.
The LLM generates SQL from user queries, but we never trust it blindly.
This module checks that:
  1. The query is a SELECT statement (nothing else allowed)
  2. No dangerous keywords like DROP, DELETE, UPDATE, INSERT are present
  3. No sneaky tricks like stacked queries using semicolons
  4. The query only touches tables that actually exist
"""

import re
from utils.logger import get_logger

logger = get_logger(__name__)

# These are the only tables the LLM should be querying
ALLOWED_TABLES = {"events", "actors", "locations", "cameo_codes"}

# If any of these appear anywhere in the query, reject it
BLOCKED_KEYWORDS = [
    "DROP", "DELETE", "UPDATE", "INSERT", "ALTER", "CREATE",
    "REPLACE", "TRUNCATE", "GRANT", "REVOKE", "EXEC",
    "ATTACH", "DETACH", "PRAGMA", "VACUUM",
]

def fix_sql_for_sqlite(sql: str) -> str:
    """Fix common PostgreSQL syntax that SQLCoder generates but SQLite doesn't support."""
    if not sql:
        return sql

    # date_trunc('week', col) -> strftime('%Y-%W', col)
    sql = re.sub(
        r"date_trunc\(\s*'week'\s*,\s*(\w+)\s*\)",
        r"strftime('%Y-%W', \1)",
        sql, flags=re.IGNORECASE,
    )

    # date_trunc('month', col) -> strftime('%Y-%m', col)
    sql = re.sub(
        r"date_trunc\(\s*'month'\s*,\s*(\w+)\s*\)",
        r"strftime('%Y-%m', \1)",
        sql, flags=re.IGNORECASE,
    )

    # date_trunc('year', col) -> strftime('%Y', col)
    sql = re.sub(
        r"date_trunc\(\s*'year'\s*,\s*(\w+)\s*\)",
        r"strftime('%Y', \1)",
        sql, flags=re.IGNORECASE,
    )

    # EXTRACT(MONTH FROM col) -> CAST(strftime('%m', col) AS INTEGER)
    sql = re.sub(
        r"EXTRACT\(\s*MONTH\s+FROM\s+(\w+)\s*\)",
        r"CAST(strftime('%m', \1) AS INTEGER)",
        sql, flags=re.IGNORECASE,
    )

    # EXTRACT(YEAR FROM col) -> CAST(strftime('%Y', col) AS INTEGER)
    sql = re.sub(
        r"EXTRACT\(\s*YEAR\s+FROM\s+(\w+)\s*\)",
        r"CAST(strftime('%Y', \1) AS INTEGER)",
        sql, flags=re.IGNORECASE,
    )

    # ILIKE -> LIKE (SQLite is case-insensitive by default for ASCII)
    sql = re.sub(r'\bILIKE\b', 'LIKE', sql, flags=re.IGNORECASE)

    # NULLS LAST / NULLS FIRST — just remove them
    sql = re.sub(r'\bNULLS\s+(LAST|FIRST)\b', '', sql, flags=re.IGNORECASE)

    # Common misspellings the LLM might pass through
    misspellings = {
        "Kartum": "Khartoum",
        "Karthoum": "Khartoum",
        "Khartum": "Khartoum",
        "Darfor": "Darfur",
        "Darfoor": "Darfur",
        "Khartoom": "Khartoum",
        "Sudaan": "Sudan",
    }
    for wrong, right in misspellings.items():
        sql = sql.replace(wrong, right)
        sql = sql.replace(wrong.upper(), right)
        sql = sql.replace(wrong.lower(), right.lower())

    return sql.strip()

def validate_sql(sql: str) -> dict:
    """Check if a SQL query is safe to execute.

    Returns:
        {
            "valid": True/False,
            "cleaned_sql": the query with whitespace tidied up,
            "error": None or a string explaining what's wrong
        }
    """
    if not sql or not sql.strip():
        return {"valid": False, "cleaned_sql": "", "error": "Empty query"}

    cleaned = sql.strip()

    # Remove trailing semicolons (the LLM sometimes adds them)
    cleaned = fix_sql_for_sqlite(cleaned)

    # Check for multiple statements (semicolons in the middle)
    if ";" in cleaned:
        logger.warning(f"Blocked stacked query: {cleaned[:100]}")
        return {"valid": False, "cleaned_sql": cleaned, "error": "Multiple statements not allowed"}

    # Must start with SELECT (case-insensitive)
    if not cleaned.upper().startswith("SELECT"):
        logger.warning(f"Blocked non-SELECT query: {cleaned[:100]}")
        return {"valid": False, "cleaned_sql": cleaned, "error": "Only SELECT queries are allowed"}

    # Scan for dangerous keywords
    upper_sql = cleaned.upper()
    for keyword in BLOCKED_KEYWORDS:
        # Use word boundary matching so "UPDATED" in a column name doesn't trigger it
        pattern = r'\b' + keyword + r'\b'
        if re.search(pattern, upper_sql):
            logger.warning(f"Blocked query containing {keyword}: {cleaned[:100]}")
            return {
                "valid": False,
                "cleaned_sql": cleaned,
                "error": f"Forbidden keyword: {keyword}",
            }

    logger.info(f"SQL validated OK: {cleaned[:100]}")
    return {"valid": True, "cleaned_sql": cleaned, "error": None}


if __name__ == "__main__":
    test_queries = [
        "SELECT * FROM events WHERE actor1_name = 'RSF'",
        "SELECT COUNT(*) FROM events GROUP BY event_date",
        "DROP TABLE events",
        "SELECT * FROM events; DELETE FROM events",
        "UPDATE events SET actor1_name = 'hacked'",
        "",
        "INSERT INTO events VALUES (1, 2, 3)",
        "SELECT * FROM events WHERE event_description LIKE '%assault%'",
    ]

    print("Testing SQL validator:\n")
    for q in test_queries:
        result = validate_sql(q)
        status = "PASS" if result["valid"] else "BLOCK"
        error = f" ({result['error']})" if result["error"] else ""
        print(f"  [{status}] {q[:60]}{error}")