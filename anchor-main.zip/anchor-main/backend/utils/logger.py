"""
logger.py

Sets up a logger that writes to two places at once:
  1. The terminal (so you can see what's happening while developing)
  2. A file at data/anchor.log (persistent record, required by client)

Usage in any file:
  from utils.logger import get_logger
  logger = get_logger(__name__)
  logger.info("Something happened")
  logger.error("Something broke", exc_info=True)
"""

import os
import sys
import logging

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import settings


def get_logger(name: str) -> logging.Logger:
    """Creates a logger that outputs to both terminal and log file."""

    logger = logging.getLogger(name)

    # Only add handlers once (prevents duplicate log lines if called multiple times)
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    # Format: timestamp - module name - level - message
    formatter = logging.Formatter(
        "%(asctime)s | %(name)s | %(levelname)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    # Terminal output
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    console.setFormatter(formatter)
    logger.addHandler(console)

    # File output
    log_dir = os.path.dirname(settings.DATABASE_PATH)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, "anchor.log")

    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)

    return logger


if __name__ == "__main__":
    logger = get_logger("test")
    logger.info("This shows in terminal AND in data/anchor.log")
    logger.warning("Warnings work too")
    logger.error("So do errors")
    print(f"\nCheck the log file at: {os.path.dirname(settings.DATABASE_PATH)}/anchor.log")