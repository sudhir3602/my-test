"""
main.py

Entry point for the Anchor backend. Run with:
  cd backend
  uvicorn main:app --reload --port 8000
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config import settings
from database.db import create_tables
from api.routes import router
from utils.logger import get_logger

logger = get_logger(__name__)

app = FastAPI(
    title="Project Anchor",
    description="AI-driven intelligence dashboard for DFAT",
    version="0.1.0",
)

# Allow the React frontend to talk to this backend
# Without CORS, the browser blocks requests from localhost:5173 to localhost:8000
app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.FRONTEND_URL, "http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register the API routes
app.include_router(router)


@app.on_event("startup")
def on_startup():
    """Runs once when the server starts."""
    logger.info("Anchor backend starting up...")
    create_tables()
    logger.info(f"Model: {settings.ANCHOR_MODEL}")
    logger.info(f"Database: {settings.DATABASE_PATH}")
    logger.info("Ready to accept queries.")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)