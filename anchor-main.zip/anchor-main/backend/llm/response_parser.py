"""
response_parser.py

Extracts the JSON payload from the LLM's raw text output.
LLMs are unpredictable with formatting — sometimes they wrap JSON
in markdown backticks, sometimes they add explanations before or after,
sometimes they use single quotes instead of double quotes.
This parser handles all of that gracefully.
"""

import re
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from utils.logger import get_logger

logger = get_logger(__name__)

# These are the fields we expect in the LLM's JSON response
REQUIRED_FIELDS = {"sql"}
OPTIONAL_FIELDS = {"chart_type", "title", "x_label", "y_label"}
VALID_CHART_TYPES = {"line", "bar", "scatter", "stacked_area", "table", "map", "network"}


def parse_llm_response(raw_text: str) -> dict:
    """Extract SQL and chart config from the LLM's response.

    Returns:
        {
            "sql": "SELECT ...",
            "chart_type": "line",
            "title": "...",
            "x_label": "...",
            "y_label": "...",
            "parse_error": None or error string
        }
    """
    if not raw_text or not raw_text.strip():
        return _error_result("LLM returned empty response")

    # Try multiple extraction strategies in order of reliability
    parsed = None

    # Strategy 1: direct JSON parse (best case — LLM followed instructions perfectly)
    parsed = _try_direct_parse(raw_text)

    # Strategy 2: find JSON block inside markdown backticks
    if not parsed:
        parsed = _try_extract_from_markdown(raw_text)

    # Strategy 3: find anything that looks like {...} in the text
    if not parsed:
        parsed = _try_extract_braces(raw_text)

    # Strategy 4: try to find just a SQL query in the text
    if not parsed:
        parsed = _try_extract_bare_sql(raw_text)

    if not parsed:
        logger.warning(f"Could not parse LLM response: {raw_text[:200]}")
        return _error_result(f"Could not parse LLM response")

    # Validate and clean up
    return _validate_and_clean(parsed)


def _try_direct_parse(text: str) -> dict | None:
    """Try parsing the entire text as JSON."""
    try:
        return json.loads(text.strip())
    except json.JSONDecodeError:
        return None


def _try_extract_from_markdown(text: str) -> dict | None:
    """Look for JSON inside ```json ... ``` or ``` ... ``` blocks."""
    patterns = [
        r'```json\s*(.*?)\s*```',
        r'```\s*(.*?)\s*```',
    ]
    for pattern in patterns:
        match = re.search(pattern, text, re.DOTALL)
        if match:
            try:
                return json.loads(match.group(1))
            except json.JSONDecodeError:
                continue
    return None


def _try_extract_braces(text: str) -> dict | None:
    """Find the first { ... } block and try to parse it as JSON."""
    start = text.find("{")
    if start == -1:
        return None

    # Find the matching closing brace (handles nested braces)
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i + 1])
                except json.JSONDecodeError:
                    return None
    return None


def _try_extract_bare_sql(text: str) -> dict | None:
    """Last resort — if the LLM just wrote a SQL query without JSON wrapping."""
    # Look for SELECT ... (possibly ending with a semicolon)
    match = re.search(r'(SELECT\s+.+?)(?:;|\Z)', text, re.IGNORECASE | re.DOTALL)
    if match:
        sql = match.group(1).strip()
        logger.info("Extracted bare SQL (no JSON wrapper)")
        return {"sql": sql, "chart_type": "table", "title": "Query Results"}
    return None


def _validate_and_clean(parsed: dict) -> dict:
    """Make sure the parsed JSON has the required fields and sensible values."""
    result = {
        "sql": parsed.get("sql", ""),
        "chart_type": parsed.get("chart_type", "table"),
        "title": parsed.get("title", "Query Results"),
        "x_label": parsed.get("x_label", ""),
        "y_label": parsed.get("y_label", ""),
        "parse_error": None,
    }

    if not result["sql"]:
        return _error_result("LLM response contained no SQL query")

    # Normalize chart type
    result["chart_type"] = result["chart_type"].lower().strip()
    if result["chart_type"] not in VALID_CHART_TYPES:
        logger.warning(f"Unknown chart type '{result['chart_type']}', falling back to table")
        result["chart_type"] = "table"

    return result


def _error_result(message: str) -> dict:
    """Build a standardised error response."""
    return {
        "sql": "",
        "chart_type": "error",
        "title": "",
        "x_label": "",
        "y_label": "",
        "parse_error": message,
    }


if __name__ == "__main__":
    # Test with different kinds of messy LLM output
    test_cases = [
        # Clean JSON (best case)
        '{"sql": "SELECT event_date, COUNT(*) FROM events GROUP BY event_date", "chart_type": "line", "title": "Events Over Time", "x_label": "Date", "y_label": "Count"}',

        # Wrapped in markdown
        'Here is your query:\n```json\n{"sql": "SELECT actor1_name, COUNT(*) FROM events GROUP BY actor1_name", "chart_type": "bar", "title": "Top Actors"}\n```',

        # Extra text around JSON
        'I will help you with that.\n{"sql": "SELECT * FROM events LIMIT 10", "chart_type": "table", "title": "Sample Events"}\nLet me know if you need more.',

        # Bare SQL (no JSON at all)
        'SELECT event_date, COUNT(*) FROM events WHERE actor1_name = "RSF" GROUP BY event_date;',

        # Total garbage
        'I am a helpful assistant and I like video games!',
    ]

    print("Testing response parser:\n")
    for i, text in enumerate(test_cases):
        result = parse_llm_response(text)
        status = "OK" if not result["parse_error"] else "FAIL"
        sql_preview = result["sql"][:60] if result["sql"] else "(none)"
        print(f"  Test {i + 1} [{status}]: chart={result['chart_type']}, sql={sql_preview}")
        if result["parse_error"]:
            print(f"         Error: {result['parse_error']}")