"""
prompt_templates.py

Prompt templates formatted to match SQLCoder's training format.
The ### Instructions / ### Input / ### Response structure is used
because most SQL-oriented models expect this layout.
"""


SCHEMA = """CREATE TABLE events (
    global_event_id INTEGER PRIMARY KEY, -- Unique ID for each event
    event_date TEXT, -- Date of the event in YYYY-MM-DD format
    year INTEGER, -- Year of the event
    month INTEGER, -- Month of the event
    day INTEGER, -- Day of the event
    actor1_name TEXT, -- First actor involved e.g. RSF, SAF, Sudan, Egypt, Hemedti, Burhan
    actor1_country_code TEXT, -- Country code of first actor e.g. SDN, EGY, SSD
    actor1_type TEXT, -- Type of first actor e.g. MIL, GOV, REB, CVL
    actor2_name TEXT, -- Second actor involved, same format as actor1
    actor2_country_code TEXT, -- Country code of second actor
    actor2_type TEXT, -- Type of second actor
    event_code TEXT, -- CAMEO event code like 190 or 036
    event_base_code TEXT, -- Base CAMEO code
    event_root_code TEXT, -- Root CAMEO code
    event_description TEXT, -- Human readable event type e.g. Fight, Appeal, Threaten, Protest
    cameo_bucket TEXT, -- Broad category e.g. Armed Conflict, Diplomacy, Protest, Cooperation, Assault, Verbal Conflict, Threat
    quad_class INTEGER, -- 1=Verbal Cooperation, 2=Material Cooperation, 3=Verbal Conflict, 4=Material Conflict
    goldstein_scale REAL, -- Conflict intensity from -10 (hostile) to +10 (cooperative)
    num_mentions INTEGER, -- Number of mentions in media
    num_sources INTEGER, -- Number of distinct sources
    num_articles INTEGER, -- Number of articles about this event
    avg_tone REAL, -- Average media tone, negative means hostile, positive means positive
    action_geo_name TEXT, -- Location name e.g. Khartoum, Khartoum, Sudan
    action_geo_lat REAL, -- Latitude of event location
    action_geo_long REAL, -- Longitude of event location
    action_geo_country TEXT, -- Country code of event location e.g. SU, EG
    source_url TEXT, -- URL of the source article
    date_added TEXT, -- When the event was added to GDELT
    ingested_at TIMESTAMP -- When we ingested this event
);"""


def build_full_prompt(user_query: str, conversation_history: list = None) -> str:
    """Build the complete prompt for the LLM.

    Returns one single string sent to Ollama as the prompt.
    """

    context = ""
    if conversation_history:
        context = "\nPrevious queries for context:\n"
        for turn in conversation_history[-3:]:
            context += f"- Question: {turn['user']}\n  SQL: {turn['sql']}\n"
        context += "\n"

    return f"""### Instructions:
Your task is to convert a question into a SQL query, given a SQLite database schema.
Adhere to these rules:
- **Deliberately go through the question and database schema word by word** to appropriately answer the question
- **Use Table Aliases** to prevent ambiguity
- When creating a ratio, always cast the numerator as float
- Only write SELECT statements, never INSERT, UPDATE, DELETE or DROP
- When searching for an actor, check BOTH actor1_name and actor2_name
- Use LIKE with % wildcards for partial name matching
- If a user misspells a name, use your best judgement to correct it. For example "Kartum" should become "Khartoum", "Darfor" should become "Darfur"
- Always include an ORDER BY clause
- Limit results to 500 rows maximum
- Never use NULLS FIRST or NULLS LAST
- This is a SQLite database, NOT PostgreSQL
- There is ONLY ONE table called "events". Do NOT reference any other tables
- Do NOT use JOIN. All columns are in the events table
- The Sudan civil war data starts from 2023-04-15. Do not filter for years before 2023 unless asked
- Do NOT use date_trunc, use strftime instead
- For weekly grouping use: strftime('%Y-%W', event_date)
- For monthly grouping use: strftime('%Y-%m', event_date)
- For yearly grouping use: strftime('%Y', event_date)
- For date parts use strftime, not EXTRACT or DATE_PART
- For top actors, use: SELECT actor1_name, COUNT(*) FROM events GROUP BY actor1_name ORDER BY COUNT(*) DESC
{context}
### Input:
Generate a SQL query that answers the question `{user_query}`.
This query will run on a database whose schema is represented in this string:
{SCHEMA}

Here are example question-and-SQL pairs. Follow these patterns exactly:

-- Q1: How has the number of events changed week by week?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, COUNT(*) AS num_events FROM events GROUP BY week ORDER BY week;

-- Q2: How much media coverage has the conflict received over time?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, SUM(num_articles) AS total_articles, SUM(num_mentions) AS total_mentions FROM events GROUP BY week ORDER BY week;

-- Q3: Which actors have been most active overall?
-- SQL: SELECT actor1_name, COUNT(*) AS num_events FROM events WHERE actor1_name NOT LIKE '[LOC]%' AND actor1_name IS NOT NULL GROUP BY actor1_name ORDER BY num_events DESC LIMIT 20;

-- Q4: What types of events have dominated the conflict?
-- SQL: SELECT cameo_bucket, COUNT(*) AS num_events FROM events GROUP BY cameo_bucket ORDER BY num_events DESC;

-- Q5: Which regions have seen the most activity?
-- SQL: SELECT action_geo_name, COUNT(*) AS num_events FROM events WHERE action_geo_name IS NOT NULL AND action_geo_name NOT GLOB '[A-Z][A-Z][0-9]*' GROUP BY action_geo_name ORDER BY num_events DESC LIMIT 20;

-- Q6: How has conflict intensity in Khartoum changed over time?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, AVG(goldstein_scale) AS avg_intensity, COUNT(*) AS num_events FROM events WHERE action_geo_name LIKE '%Khartoum%' GROUP BY week ORDER BY week;

-- Q7: How does RSF activity compare to SAF activity week by week?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, SUM(CASE WHEN actor1_name = 'RSF' OR actor2_name = 'RSF' THEN 1 ELSE 0 END) AS rsf_events, SUM(CASE WHEN actor1_name = 'SAF' OR actor2_name = 'SAF' THEN 1 ELSE 0 END) AS saf_events FROM events GROUP BY week ORDER BY week;

-- Q8: Has the conflict been getting more or less violent over time?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, AVG(goldstein_scale) AS avg_intensity, SUM(CASE WHEN quad_class = 4 THEN 1 ELSE 0 END) AS material_conflict_events FROM events GROUP BY week ORDER BY week;

-- Q9: How does media attention compare to event count?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, COUNT(*) AS num_events, SUM(num_articles) AS total_articles FROM events GROUP BY week ORDER BY week;

-- Q10: Which event types dominate in Khartoum compared to Darfur?
-- SQL: SELECT cameo_bucket, SUM(CASE WHEN action_geo_name LIKE '%Khartoum%' THEN 1 ELSE 0 END) AS khartoum_events, SUM(CASE WHEN action_geo_name LIKE '%Darfur%' THEN 1 ELSE 0 END) AS darfur_events FROM events GROUP BY cameo_bucket ORDER BY khartoum_events + darfur_events DESC;

-- Q11: Which actors are both highly active and highly hostile?
-- SQL: SELECT actor1_name, COUNT(*) AS num_events, AVG(goldstein_scale) AS avg_hostility FROM events WHERE actor1_name NOT LIKE '[LOC]%' AND actor1_name IS NOT NULL GROUP BY actor1_name HAVING COUNT(*) > 10 ORDER BY avg_hostility ASC LIMIT 20;

-- Q12: Where is RSF most active?
-- SQL: SELECT action_geo_name, COUNT(*) AS num_events FROM events WHERE (actor1_name = 'RSF' OR actor2_name = 'RSF') AND action_geo_name IS NOT NULL AND action_geo_name NOT GLOB '[A-Z][A-Z][0-9]*' GROUP BY action_geo_name ORDER BY num_events DESC LIMIT 20;

-- Q13: What share of events each month were Armed Conflict?
-- SQL: SELECT strftime('%Y-%m', event_date) AS month, SUM(CASE WHEN cameo_bucket = 'Armed Conflict' THEN 1 ELSE 0 END) AS armed_conflict, SUM(CASE WHEN cameo_bucket = 'Diplomacy' THEN 1 ELSE 0 END) AS diplomacy, SUM(CASE WHEN cameo_bucket = 'Protest' THEN 1 ELSE 0 END) AS protest, COUNT(*) AS total FROM events GROUP BY month ORDER BY month;

-- Q14: Which regions saw the biggest change in activity last month?
-- SQL: SELECT action_geo_name, COUNT(*) AS num_events FROM events WHERE action_geo_name IS NOT NULL AND action_geo_name NOT GLOB '[A-Z][A-Z][0-9]*' AND event_date >= date((SELECT MAX(event_date) FROM events), '-30 days') GROUP BY action_geo_name ORDER BY num_events DESC LIMIT 20;

-- Q15: How has the geographic spread of the conflict changed over time?
-- SQL: SELECT strftime('%Y-%m', event_date) AS month, COUNT(DISTINCT action_geo_name) AS unique_locations, COUNT(*) AS num_events FROM events WHERE action_geo_name IS NOT NULL GROUP BY month ORDER BY month;

-- Q16: Which actor pairs clash most and are those clashes usually violent?
-- SQL: SELECT actor1_name, actor2_name, COUNT(*) AS num_events, AVG(goldstein_scale) AS avg_intensity, SUM(CASE WHEN quad_class = 4 THEN 1 ELSE 0 END) AS violent_events FROM events WHERE actor1_name IS NOT NULL AND actor2_name IS NOT NULL AND actor1_name NOT LIKE '[LOC]%' AND actor2_name NOT LIKE '[LOC]%' GROUP BY actor1_name, actor2_name HAVING COUNT(*) > 5 ORDER BY num_events DESC LIMIT 20;

-- Q17: Which weeks were unusually violent compared to the recent trend?
-- SQL: SELECT strftime('%Y-%W', event_date) AS week, COUNT(*) AS num_events, SUM(CASE WHEN quad_class = 4 THEN 1 ELSE 0 END) AS violent_events, AVG(goldstein_scale) AS avg_intensity FROM events GROUP BY week ORDER BY week;

-- Q18: Which actors are the most unpredictable in their behaviour?
-- SQL: SELECT actor1_name, COUNT(*) AS num_events, AVG(goldstein_scale) AS avg_score, ABS(MAX(goldstein_scale) - MIN(goldstein_scale)) AS score_range FROM events WHERE actor1_name IS NOT NULL AND actor1_name NOT LIKE '[LOC]%' GROUP BY actor1_name HAVING COUNT(*) > 10 ORDER BY score_range DESC LIMIT 20;

-- Q19: Who has been dominant in each region?
-- SQL: SELECT action_geo_name, actor1_name, COUNT(*) AS num_events FROM events WHERE action_geo_name IS NOT NULL AND actor1_name IS NOT NULL AND actor1_name NOT LIKE '[LOC]%' AND action_geo_name NOT GLOB '[A-Z][A-Z][0-9]*' GROUP BY action_geo_name, actor1_name ORDER BY action_geo_name, num_events DESC LIMIT 100;

-- Q20: Is the conflict getting better or worse?
-- SQL: SELECT strftime('%Y-%m', event_date) AS month, COUNT(*) AS total_events, SUM(CASE WHEN quad_class = 4 THEN 1 ELSE 0 END) AS violent_events, AVG(goldstein_scale) AS avg_intensity, AVG(avg_tone) AS avg_media_tone FROM events GROUP BY month ORDER BY month;

### Response:
Based on your instructions, here is the SQL query I have generated to answer the question `{user_query}`:
```sql
"""


def get_system_prompt(db_schema_summary: str = "") -> str:
    """Not used directly anymore, kept for backward compatibility."""
    return ""


def build_user_prompt(user_query: str, conversation_history: list = None) -> str:
    """Not used directly anymore, kept for backward compatibility."""
    return build_full_prompt(user_query, conversation_history)


def infer_chart_type(user_query: str, sql: str, columns: list) -> dict:
    """Pick the best chart type based on the question and query structure."""
    query_lower = user_query.lower()
    sql_lower = sql.lower()

    # Map queries when lat/long columns are present
    if any(col in columns for col in ["action_geo_lat", "action_geo_long", "latitude", "longitude"]):
        if "lat" in sql_lower and "long" in sql_lower:
            return {"chart_type": "map", "title": _make_title(user_query),
                    "x_label": "Longitude", "y_label": "Latitude"}

    # Time-based queries -> line chart
    time_keywords = ["over time", "week by week", "month by month", "trend",
                     "changed", "daily", "weekly", "monthly", "timeline",
                     "getting more", "getting less", "getting better", "getting worse",
                     "received over", "spread", "phase", "better or worse",
                     "more or less violent", "media attention compare",
                     "media coverage", "unusually violent", "geographic spread"]
    if any(kw in query_lower for kw in time_keywords):
        return {"chart_type": "line", "title": _make_title(user_query),
                "x_label": "Date", "y_label": "Count"}

    # Scatter queries (check before bar so "which actors...hostile" gets scatter not bar)
    scatter_keywords = ["correlation", "relationship between", "vs", "versus",
                        "highly active and highly hostile", "active and hostile",
                        "active and", "both highly"]
    if any(kw in query_lower for kw in scatter_keywords):
        return {"chart_type": "scatter", "title": _make_title(user_query),
                "x_label": "X", "y_label": "Y"}
    
    # Dual-metric time series - when query asks about intensity/tone over time
    intensity_keywords = ["intensity", "goldstein", "tone", "violent", "hostil"]
    if any(kw in query_lower for kw in intensity_keywords) and any(kw in query_lower for kw in time_keywords):
        return {"chart_type": "line", "title": _make_title(user_query),
                "x_label": "Date", "y_label": "Value"}

    # Comparison queries -> bar chart
    compare_keywords = ["most active", "top", "which actors", "which regions",
                        "dominated", "compare", "biggest", "highest", "lowest",
                        "most popular", "least", "ranking", "dominant",
                        "most unpredictable", "actor pairs", "clash",
                        "biggest change", "most hostile"]
    if any(kw in query_lower for kw in compare_keywords):
        return {"chart_type": "bar", "title": _make_title(user_query),
                "x_label": "Category", "y_label": "Count"}

    # Composition queries -> stacked area
    composition_keywords = ["share", "proportion", "breakdown", "composition",
                            "stacked", "what share"]
    if any(kw in query_lower for kw in composition_keywords):
        return {"chart_type": "stacked_area", "title": _make_title(user_query),
                "x_label": "Date", "y_label": "Count"}

    # If GROUP BY a date field, probably a line chart
    if "group by" in sql_lower:
        date_patterns = ["event_date", "strftime", "year", "month", "week"]
        if any(p in sql_lower for p in date_patterns):
            return {"chart_type": "line", "title": _make_title(user_query),
                    "x_label": "Date", "y_label": "Count"}

    # If GROUP BY something else, probably a bar chart
    if "group by" in sql_lower:
        return {"chart_type": "bar", "title": _make_title(user_query),
                "x_label": "Category", "y_label": "Count"}

    # Default to table
    return {"chart_type": "table", "title": _make_title(user_query),
            "x_label": "", "y_label": ""}


def _make_title(query: str) -> str:
    """Turn the user's question into a short chart title."""
    title = query.strip().rstrip("?").strip()
    if len(title) > 60:
        title = title[:57] + "..."
    return title[0].upper() + title[1:] if title else "Query Results"


if __name__ == "__main__":
    prompt = build_full_prompt("How has the number of events changed week by week?")
    print("Full prompt:")
    print(prompt)
    print(f"\nPrompt length: {len(prompt)} characters")