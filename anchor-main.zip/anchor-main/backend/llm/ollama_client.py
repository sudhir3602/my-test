"""
ollama_client.py

Sends prompts to the Ollama LLM server and returns the raw response text.
Ollama exposes a simple REST API at localhost:11434.
We just POST a JSON payload and read the response.
"""

import requests
import time
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import settings
from utils.logger import get_logger

logger = get_logger(__name__)


def query_llm(system_prompt: str, user_prompt: str) -> dict:
    """Send a prompt to Ollama and return the response with timing info.

    Returns:
        {
            "text": the raw text the LLM generated,
            "response_time_ms": how long it took,
            "model": which model was used,
            "error": None or error message
        }
    """
    url = f"{settings.OLLAMA_HOST}/api/generate"

    payload = {
        "model": settings.ANCHOR_MODEL,
        "prompt": system_prompt + "\n" + user_prompt,
        "stream": False,
        "options": {
            "temperature": 0.1,
            "num_predict": 512,
        },
    }

    start = time.time()

    try:
        logger.info(f"Sending query to {settings.ANCHOR_MODEL}...")
        response = requests.post(url, json=payload, timeout=120)
        response.raise_for_status()

        elapsed = int((time.time() - start) * 1000)
        result = response.json()

        text = result.get("response", "").strip()
        # Strip model artifacts like <s> and </s> tokens
        text = text.replace("<s>", "").replace("</s>", "").strip()
        logger.info(f"LLM responded in {elapsed}ms ({len(text)} chars)")

        return {
            "text": text,
            "response_time_ms": elapsed,
            "model": settings.ANCHOR_MODEL,
            "error": None,
        }

    except requests.ConnectionError:
        elapsed = int((time.time() - start) * 1000)
        error = f"Cannot connect to Ollama at {settings.OLLAMA_HOST}. Is it running?"
        logger.error(error)
        return {"text": "", "response_time_ms": elapsed, "model": settings.ANCHOR_MODEL, "error": error}

    except requests.Timeout:
        elapsed = int((time.time() - start) * 1000)
        error = "LLM request timed out after 120 seconds"
        logger.error(error)
        return {"text": "", "response_time_ms": elapsed, "model": settings.ANCHOR_MODEL, "error": error}

    except Exception as e:
        elapsed = int((time.time() - start) * 1000)
        error = f"LLM request failed: {str(e)}"
        logger.error(error)
        return {"text": "", "response_time_ms": elapsed, "model": settings.ANCHOR_MODEL, "error": error}


def check_ollama_status() -> dict:
    """Check if Ollama is running and the model is available."""
    try:
        # Check if Ollama is reachable
        response = requests.get(f"{settings.OLLAMA_HOST}/api/tags", timeout=10)
        response.raise_for_status()

        models = response.json().get("models", [])
        model_names = [m["name"] for m in models]

        # Check if our model is pulled
        model_ready = any(settings.ANCHOR_MODEL in name for name in model_names)

        return {
            "ollama_running": True,
            "model_ready": model_ready,
            "available_models": model_names,
        }

    except requests.ConnectionError:
        return {"ollama_running": False, "model_ready": False, "available_models": []}


if __name__ == "__main__":
    # First check if Ollama is running
    status = check_ollama_status()
    print("Ollama status:")
    print(f"  Running: {status['ollama_running']}")
    print(f"  Model ready: {status['model_ready']}")
    print(f"  Available models: {status['available_models']}")

    if not status["ollama_running"]:
        print("\nStart Ollama first, then run this again.")
    elif not status["model_ready"]:
        print(f"\nRun 'ollama pull {settings.ANCHOR_MODEL}' first.")
    else:
        # Send a quick test query
        print("\nSending test query...")
        result = query_llm(
            system_prompt="You are a helpful assistant. Respond with only: {\"status\": \"ok\"}",
            user_prompt="Are you working?",
        )
        print(f"  Response: {result['text']}")
        print(f"  Time: {result['response_time_ms']}ms")
        if result["error"]:
            print(f"  Error: {result['error']}")