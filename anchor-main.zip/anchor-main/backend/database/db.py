"""
db.py is the Database setup for this project.

Creates the SQLite database and all tables on first run.
Other files import get_connection() to interact with the database.
"""

import os
import sqlite3
from config import settings


def get_connection() -> sqlite3.Connection:
    """Open a connection to the SQLite database, creating the file if needed."""

    # Make sure the data/ folder exists before SQLite tries to create the .db file
    db_dir = os.path.dirname(settings.DATABASE_PATH)
    if db_dir:
        os.makedirs(db_dir, exist_ok=True)

    conn = sqlite3.connect(settings.DATABASE_PATH)

    # Return rows as dictionaries instead of plain tuples
    # This lets us do row["actor_name"] instead of row[3]
    conn.row_factory = sqlite3.Row

    # Turn on WAL mode which allows reads while writes are happening
    conn.execute("PRAGMA journal_mode=WAL")

    return conn


def create_tables():
    """Create all tables if they don't already exist."""

    conn = get_connection()
    cursor = conn.cursor()

    # Main table — one row per GDELT event related to Sudan
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS events (
            global_event_id     INTEGER PRIMARY KEY,
            event_date          TEXT NOT NULL,
            year                INTEGER,
            month               INTEGER,
            day                 INTEGER,

            actor1_name         TEXT,
            actor1_country_code TEXT,
            actor1_type         TEXT,
            actor2_name         TEXT,
            actor2_country_code TEXT,
            actor2_type         TEXT,

            event_code          TEXT,
            event_base_code     TEXT,
            event_root_code     TEXT,
            event_description   TEXT,
            cameo_bucket        TEXT,
            quad_class          INTEGER,
            goldstein_scale     REAL,

            num_mentions        INTEGER,
            num_sources         INTEGER,
            num_articles        INTEGER,
            avg_tone            REAL,

            action_geo_name     TEXT,
            action_geo_lat      REAL,
            action_geo_long     REAL,
            action_geo_country  TEXT,

            source_url          TEXT,
            date_added          TEXT,
            ingested_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Unique actors pulled from events for the network graph and filtering
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS actors (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            name                TEXT UNIQUE NOT NULL,
            country_code        TEXT,
            actor_type          TEXT,
            first_seen          TEXT,
            last_seen           TEXT,
            event_count         INTEGER DEFAULT 0
        )
    """)

    # Unique locations pulled from events for the map
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS locations (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            name                TEXT NOT NULL,
            latitude            REAL,
            longitude           REAL,
            country_code        TEXT,
            event_count         INTEGER DEFAULT 0,
            UNIQUE(name, latitude, longitude)
        )
    """)

    # Lookup table for CAMEO event codes into readable descriptions
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS cameo_codes (
            code                TEXT PRIMARY KEY,
            description         TEXT NOT NULL
        )
    """)

    # Tracks each GDELT file we've downloaded so we never re-download
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS ingestion_log (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            file_url            TEXT UNIQUE NOT NULL,
            rows_fetched        INTEGER,
            rows_stored         INTEGER,
            ingested_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Every query gets logged here
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS query_logs (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            user_query          TEXT,
            model_used          TEXT,
            llm_response_ms     INTEGER,
            sql_generated       TEXT,
            sql_valid           BOOLEAN,
            sql_execution_ms    INTEGER,
            rows_returned       INTEGER,
            chart_type          TEXT,
            total_response_ms   INTEGER,
            error               TEXT
        )
    """)

# Pinned charts — analyst saves a chart and it refreshes with new data
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS pinned_charts (
            id                  INTEGER PRIMARY KEY AUTOINCREMENT,
            title               TEXT NOT NULL,
            sql_query           TEXT NOT NULL,
            chart_type          TEXT NOT NULL,
            chart_config        TEXT,
            pinned_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)
    
    # Indexes speed up the queries the LLM will generate most often
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_date ON events(event_date)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_actor1 ON events(actor1_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_actor2 ON events(actor2_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_location ON events(action_geo_name)")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_events_code ON events(event_code)")

    conn.commit()
    conn.close()
    print("All tables and indexes created successfully.")


# Run directly to set up the database
if __name__ == "__main__":
    create_tables()