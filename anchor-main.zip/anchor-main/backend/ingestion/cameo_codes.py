"""
cameo_codes.py file maps GDELT CAMEO event codes to readable labels and broad buckets.

GDELT uses a system called CAMEO (Conflict and Mediation Event Observations)
to categorise every event with a numeric code. For example:
  "190" = "Use conventional military force"
  "036" = "Express intent to meet or negotiate"

The root code (first two digits) tells you the general category.
We map every root code to a human-readable bucket like "Armed Conflict"
or "Diplomacy" so the LLM and user can work with plain English.
"""

# There are 20 root codes (01–20). We group them into understandable buckets.

CAMEO_BUCKETS = {
    "01": "Public Statement",
    "02": "Diplomacy",
    "03": "Diplomacy",
    "04": "Verbal Conflict",
    "05": "Diplomacy",
    "06": "Cooperation",
    "07": "Cooperation",
    "08": "Cooperation",
    "09": "Investigation",
    "10": "Demand",
    "11": "Disapproval",
    "12": "Rejection",
    "13": "Threat",
    "14": "Protest",
    "15": "Force Posture",
    "16": "Reduction of Relations",
    "17": "Coercion",
    "18": "Assault",
    "19": "Armed Conflict",
    "20": "Unconventional Violence",
}

# These are the official CAMEO root-level descriptions, slightly shortened.

CAMEO_ROOT_DESCRIPTIONS = {
    "01": "Make public statement",
    "02": "Appeal",
    "03": "Express intent to cooperate",
    "04": "Consult",
    "05": "Engage in diplomatic cooperation",
    "06": "Engage in material cooperation",
    "07": "Provide aid",
    "08": "Yield",
    "09": "Investigate",
    "10": "Demand",
    "11": "Disapprove",
    "12": "Reject",
    "13": "Threaten",
    "14": "Protest",
    "15": "Exhibit force posture",
    "16": "Reduce relations",
    "17": "Coerce",
    "18": "Assault",
    "19": "Fight",
    "20": "Use unconventional mass violence",
}


def get_event_description(event_code: str) -> str:
    """Turn a CAMEO event code like '194' into a readable description."""
    if not event_code:
        return "Unknown"

    # The root code is the first two digits
    root = event_code[:2]
    return CAMEO_ROOT_DESCRIPTIONS.get(root, "Unknown")


def get_cameo_bucket(event_code: str) -> str:
    """Turn a CAMEO event code like '194' into a broad bucket like 'Armed Conflict'."""
    if not event_code:
        return "Unknown"

    root = event_code[:2]
    return CAMEO_BUCKETS.get(root, "Unknown")


# Quick test
if __name__ == "__main__":
    test_codes = ["010", "036", "141", "190", "194", "201", "999", ""]
    print("-" * 65)
    for code in test_codes:
        desc = get_event_description(code)
        bucket = get_cameo_bucket(code)
        print(f"{code:5s} → {desc:35s} → {bucket}")