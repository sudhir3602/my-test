"""
run_ingestion.py

Two modes:
  python -m ingestion.run_ingestion backfill 2023-04-15 2024-04-07
      Downloads daily GDELT files for the given date range.

  python -m ingestion.run_ingestion live
      Pulls the latest GDELT file every 15 minutes until you stop it.

  python -m ingestion.run_ingestion both 2023-04-15 2024-04-07
      Backfills first, then starts the live scheduler.
"""

import os
import sys
import time
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import settings
from database.db import create_tables
from ingestion.gdelt_fetcher import fetch_latest, fetch_historical
from ingestion.gdelt_processor import process_csv


def run_backfill(start_date: str, end_date: str):
    """Download and process all daily GDELT files in a date range."""
    print(f"\nStarting backfill from {start_date} to {end_date}")
    print("This will take a while for large ranges. Go grab a coffee.\n")

    results = fetch_historical(start_date, end_date)
    total = 0
    for csv_text, url in results:
        rows = process_csv(csv_text, url)
        total += rows

    print(f"\nBackfill complete. {total} total Sudan events stored.")


def run_live():
    """Pull the latest GDELT data every 15 minutes."""
    from apscheduler.schedulers.blocking import BlockingScheduler

    def fetch_and_process():
        print(f"\n[{datetime.now().strftime('%H:%M:%S')}] Checking for new GDELT data...")
        csv_text, url = fetch_latest()
        if csv_text:
            process_csv(csv_text, url)
        else:
            print("Nothing new to process.")

    # Run once immediately, then schedule
    fetch_and_process()

    scheduler = BlockingScheduler()
    scheduler.add_job(
        fetch_and_process,
        "interval",
        minutes=settings.GDELT_UPDATE_INTERVAL,
    )

    print(f"\nScheduler running. Pulling new data every {settings.GDELT_UPDATE_INTERVAL} minutes.")
    print("Press Ctrl+C to stop.\n")

    try:
        scheduler.start()
    except KeyboardInterrupt:
        print("\nScheduler stopped.")


def print_usage():
    print("Usage:")
    print("  python -m ingestion.run_ingestion backfill 2023-04-15 2024-04-07")
    print("  python -m ingestion.run_ingestion live")
    print("  python -m ingestion.run_ingestion both 2023-04-15 2024-04-07")


if __name__ == "__main__":
    # Make sure tables exist before doing anything
    create_tables()

    args = sys.argv[1:]

    if not args:
        print_usage()
        sys.exit(1)

    mode = args[0].lower()

    if mode == "backfill" and len(args) == 3:
        run_backfill(args[1], args[2])

    elif mode == "live":
        run_live()

    elif mode == "both" and len(args) == 3:
        run_backfill(args[1], args[2])
        run_live()

    else:
        print_usage()