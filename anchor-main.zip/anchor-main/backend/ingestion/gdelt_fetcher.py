"""
gdelt_fetcher.py  downloads GDELT event CSV files from the internet.

GDELT publishes new data every 15 minutes as zipped CSV files.
This module handles:
  1. Fetching the latest update URL
  2. Downloading and unzipping the CSV
  3. Downloading historical files by date for backfilling
  4. Skipping files we've already downloaded (using ingestion_log table)
"""

import os
import io
import zipfile
import requests
import sqlite3
from datetime import datetime, timedelta

import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import settings

# GDELT base URLs
LAST_UPDATE_URL = "http://data.gdeltproject.org/gdeltv2/lastupdate.txt"
GDELT_BASE_URL = "http://data.gdeltproject.org/gdeltv2/"

# Column names for the GDELT 2.0 Event export
# Full spec: https://www.gdeltproject.org/data/lookups/CSV.header.fieldids.xlsx
GDELT_COLUMNS = [
    "GlobalEventID", "Day", "MonthYear", "Year", "FractionDate",
    "Actor1Code", "Actor1Name", "Actor1CountryCode", "Actor1KnownGroupCode",
    "Actor1EthnicCode", "Actor1Religion1Code", "Actor1Religion2Code",
    "Actor1Type1Code", "Actor1Type2Code", "Actor1Type3Code",
    "Actor2Code", "Actor2Name", "Actor2CountryCode", "Actor2KnownGroupCode",
    "Actor2EthnicCode", "Actor2Religion1Code", "Actor2Religion2Code",
    "Actor2Type1Code", "Actor2Type2Code", "Actor2Type3Code",
    "IsRootEvent", "EventCode", "EventBaseCode", "EventRootCode",
    "QuadClass", "GoldsteinScale", "NumMentions", "NumSources", "NumArticles",
    "AvgTone",
    "Actor1Geo_Type", "Actor1Geo_FullName", "Actor1Geo_CountryCode",
    "Actor1Geo_ADM1Code", "Actor1Geo_ADM2Code",
    "Actor1Geo_Lat", "Actor1Geo_Long", "Actor1Geo_FeatureID",
    "Actor2Geo_Type", "Actor2Geo_FullName", "Actor2Geo_CountryCode",
    "Actor2Geo_ADM1Code", "Actor2Geo_ADM2Code",
    "Actor2Geo_Lat", "Actor2Geo_Long", "Actor2Geo_FeatureID",
    "ActionGeo_Type", "ActionGeo_FullName", "ActionGeo_CountryCode",
    "ActionGeo_ADM1Code", "ActionGeo_ADM2Code",
    "ActionGeo_Lat", "ActionGeo_Long", "ActionGeo_FeatureID",
    "DATEADDED", "SOURCEURL",
]
# GDELT 1.0 has 58 columns (no ADM2Code fields)
GDELT_V1_COLUMNS = [
    "GlobalEventID", "Day", "MonthYear", "Year", "FractionDate",
    "Actor1Code", "Actor1Name", "Actor1CountryCode", "Actor1KnownGroupCode",
    "Actor1EthnicCode", "Actor1Religion1Code", "Actor1Religion2Code",
    "Actor1Type1Code", "Actor1Type2Code", "Actor1Type3Code",
    "Actor2Code", "Actor2Name", "Actor2CountryCode", "Actor2KnownGroupCode",
    "Actor2EthnicCode", "Actor2Religion1Code", "Actor2Religion2Code",
    "Actor2Type1Code", "Actor2Type2Code", "Actor2Type3Code",
    "IsRootEvent", "EventCode", "EventBaseCode", "EventRootCode",
    "QuadClass", "GoldsteinScale", "NumMentions", "NumSources", "NumArticles",
    "AvgTone",
    "Actor1Geo_Type", "Actor1Geo_FullName", "Actor1Geo_CountryCode",
    "Actor1Geo_ADM1Code", "Actor1Geo_Lat", "Actor1Geo_Long",
    "Actor1Geo_FeatureID",
    "Actor2Geo_Type", "Actor2Geo_FullName", "Actor2Geo_CountryCode",
    "Actor2Geo_ADM1Code", "Actor2Geo_Lat", "Actor2Geo_Long",
    "Actor2Geo_FeatureID",
    "ActionGeo_Type", "ActionGeo_FullName", "ActionGeo_CountryCode",
    "ActionGeo_ADM1Code", "ActionGeo_Lat", "ActionGeo_Long",
    "ActionGeo_FeatureID",
    "DATEADDED", "SOURCEURL",
]

def already_downloaded(file_url: str) -> bool:
    """Check the ingestion_log table to see if we've already processed this file."""
    try:
        conn = sqlite3.connect(settings.DATABASE_PATH)
        cursor = conn.execute(
            "SELECT COUNT(*) FROM ingestion_log WHERE file_url = ?", (file_url,)
        )
        count = cursor.fetchone()[0]
        conn.close()
        return count > 0
    except Exception:
        return False


def get_latest_export_url() -> str | None:
    """Fetch the GDELT lastupdate.txt and return the export CSV URL."""
    try:
        response = requests.get(LAST_UPDATE_URL, timeout=30)
        response.raise_for_status()

        # lastupdate.txt has 3 lines — export, mentions, gkg
        # We want the line containing ".export.CSV.zip"
        for line in response.text.strip().split("\n"):
            if ".export.CSV.zip" in line:
                parts = line.strip().split(" ")
                return parts[-1]  # URL is the last field on the line

        print("Could not find export URL in lastupdate.txt")
        return None
    except requests.RequestException as e:
        print(f"Failed to fetch lastupdate.txt: {e}")
        return None


def build_historical_url(date: datetime) -> str:
    """Build a GDELT 1.0 daily export URL for backfilling.

    GDELT 1.0 gives us one file per day with ALL events (not just 15 mins).
    Format: http://data.gdeltproject.org/events/20240101.export.CSV.zip
    """
    date_str = date.strftime("%Y%m%d")
    return f"http://data.gdeltproject.org/events/{date_str}.export.CSV.zip"


def download_and_extract(file_url: str) -> str | None:
    """Download a zipped GDELT CSV and return the raw CSV text.

    Returns None if the download fails or the file was already processed.
    """
    if already_downloaded(file_url):
        print(f"Skipping (already downloaded): {file_url}")
        return None

    try:
        print(f"Downloading: {file_url}")
        response = requests.get(file_url, timeout=60)
        response.raise_for_status()

        # The response is a ZIP file containing one CSV
        zip_buffer = io.BytesIO(response.content)
        with zipfile.ZipFile(zip_buffer) as zf:
            csv_filename = zf.namelist()[0]
            csv_text = zf.read(csv_filename).decode("utf-8", errors="replace")

        return csv_text

    except requests.RequestException as e:
        print(f"Download failed: {e}")
        return None
    except zipfile.BadZipFile:
        print(f"Bad zip file: {file_url}")
        return None


def fetch_latest() -> tuple[str | None, str | None]:
    """Download the most recent GDELT export. Returns (csv_text, file_url)."""
    url = get_latest_export_url()
    if not url:
        return None, None

    csv_text = download_and_extract(url)
    return csv_text, url


def fetch_historical(start_date: str, end_date: str) -> list[tuple[str, str]]:
    """Download daily GDELT exports for a date range.

    Args:
        start_date: "YYYY-MM-DD" format
        end_date:   "YYYY-MM-DD" format

    Returns:
        List of (csv_text, file_url) tuples for successful downloads.
    """
    start = datetime.strptime(start_date, "%Y-%m-%d")
    end = datetime.strptime(end_date, "%Y-%m-%d")
    results = []

    current = start
    while current <= end:
        url = build_historical_url(current)
        csv_text = download_and_extract(url)
        if csv_text:
            results.append((csv_text, url))
        current += timedelta(days=1)

    print(f"Downloaded {len(results)} files from {start_date} to {end_date}")
    return results


# Quick test: download the latest file and show how many lines it has
if __name__ == "__main__":
    print("Fetching latest GDELT export...")
    csv_text, url = fetch_latest()
    if csv_text:
        lines = csv_text.strip().split("\n")
        print(f"URL: {url}")
        print(f"Total lines (worldwide events): {len(lines)}")
        print(f"First line preview: {lines[0][:200]}...")
    else:
        print("No data fetched.")