"""
gdelt_processor.py cleans raw GDELT CSV data and stores Sudan events in SQLite.

Takes the raw CSV text from gdelt_fetcher, then:
  1. Parses it into a pandas DataFrame using the 61 GDELT column names
  2. Filters for Sudan-related events only
  3. Normalizes actor names (so "RSF" and "RAPID SUPPORT FORCES" become one)
  4. Adds human-readable event descriptions and CAMEO buckets
  5. Inserts cleaned rows into the events table
  6. Updates the actors and locations tables
  7. Logs the ingestion in ingestion_log
"""

import os
import sys
import sqlite3
import pandas as pd
from io import StringIO
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config import settings
from ingestion.gdelt_fetcher import GDELT_COLUMNS, GDELT_V1_COLUMNS
from ingestion.cameo_codes import get_event_description, get_cameo_bucket
import json

# Path to the external config file
ACTOR_CONFIG_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "data", "actor_config.json")

_config_cache = {"data": None, "mtime": 0}

def load_actor_config() -> dict:
    """Load the actor config from JSON, cached until the file changes."""
    try:
        current_mtime = os.path.getmtime(ACTOR_CONFIG_PATH)
        if _config_cache["data"] is not None and _config_cache["mtime"] == current_mtime:
            return _config_cache["data"]

        with open(ACTOR_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        _config_cache["data"] = data
        _config_cache["mtime"] = current_mtime
        return data
    except FileNotFoundError:
        print(f"WARNING: {ACTOR_CONFIG_PATH} not found, using empty config")
        return {
            "country_codes": [],
            "filter_keywords": [],
            "actor_name_map": {},
            "location_actors": [],
        }


def is_sudan_related(row: pd.Series) -> bool:
    """Check if a GDELT event row is related to the configured conflict."""
    config = load_actor_config()
    country_codes = set(config.get("country_codes", []))
    keywords = config.get("filter_keywords", [])

    for col in ["Actor1CountryCode", "Actor2CountryCode", "ActionGeo_CountryCode"]:
        val = str(row.get(col, "")).strip().upper()
        if val in country_codes:
            return True

    text_fields = ["Actor1Name", "Actor2Name", "ActionGeo_FullName"]
    combined = " ".join(str(row.get(f, "")) for f in text_fields).upper()
    for keyword in keywords:
        if keyword in combined:
            return True

    return False


def normalize_actor_name(name: str) -> str:
    """Clean up an actor name using the external config file."""
    if not name or not isinstance(name, str):
        return name

    config = load_actor_config()
    actor_map = config.get("actor_name_map", {})
    location_actors = set(config.get("location_actors", []))

    upper = name.strip().upper()

    if upper in location_actors:
        return f"[LOC] {name.strip().title()}"

    for pattern, clean_name in actor_map.items():
        if pattern in upper:
            return clean_name

    return name.strip().title()


def process_csv(csv_text: str, file_url: str) -> int:
    """Parse raw GDELT CSV text, filter for Sudan, clean, and store in SQLite.

    Returns the number of Sudan-related rows stored.
    """
    # Parse the tab-separated CSV (GDELT uses tabs, not commas)
    # Detect column count to choose the right header list
    first_line = csv_text.strip().split("\n")[0]
    col_count = len(first_line.split("\t"))

    if col_count <= 58:
        columns = GDELT_V1_COLUMNS
    else:
        columns = GDELT_COLUMNS

    df = pd.read_csv(
        StringIO(csv_text),
        sep="\t",
        header=None,
        names=columns[:col_count],
        dtype=str,
        on_bad_lines="skip",
    )

    # Filter for Sudan-related events
    sudan_mask = df.apply(is_sudan_related, axis=1)
    df_sudan = df[sudan_mask].copy()

    if df_sudan.empty:
        print(f"No Sudan events found in {file_url}")
        log_ingestion(file_url, len(df), 0)
        return 0

    # Parse the date column (format: YYYYMMDD)
    df_sudan["event_date"] = pd.to_datetime(df_sudan["Day"], format="%Y%m%d", errors="coerce")
    df_sudan["year"] = df_sudan["event_date"].dt.year
    df_sudan["month"] = df_sudan["event_date"].dt.month
    df_sudan["day"] = df_sudan["event_date"].dt.day
    df_sudan["event_date"] = df_sudan["event_date"].dt.strftime("%Y-%m-%d")

    # Normalize actor names
    df_sudan["Actor1Name"] = df_sudan["Actor1Name"].apply(normalize_actor_name)
    df_sudan["Actor2Name"] = df_sudan["Actor2Name"].apply(normalize_actor_name)

    # Add CAMEO descriptions and buckets
    df_sudan["event_description"] = df_sudan["EventCode"].apply(get_event_description)
    df_sudan["cameo_bucket"] = df_sudan["EventCode"].apply(get_cameo_bucket)

    # Convert numeric columns from strings to proper types
    numeric_cols = {
        "GlobalEventID": "int64",
        "QuadClass": "float64",
        "GoldsteinScale": "float64",
        "NumMentions": "float64",
        "NumSources": "float64",
        "NumArticles": "float64",
        "AvgTone": "float64",
        "ActionGeo_Lat": "float64",
        "ActionGeo_Long": "float64",
    }
    for col, dtype in numeric_cols.items():
        df_sudan[col] = pd.to_numeric(df_sudan[col], errors="coerce")

    # Build the final DataFrame matching our events table columns
    events_df = pd.DataFrame({
        "global_event_id": df_sudan["GlobalEventID"],
        "event_date": df_sudan["event_date"],
        "year": df_sudan["year"],
        "month": df_sudan["month"],
        "day": df_sudan["day"],
        "actor1_name": df_sudan["Actor1Name"],
        "actor1_country_code": df_sudan["Actor1CountryCode"],
        "actor1_type": df_sudan["Actor1Type1Code"],
        "actor2_name": df_sudan["Actor2Name"],
        "actor2_country_code": df_sudan["Actor2CountryCode"],
        "actor2_type": df_sudan["Actor2Type1Code"],
        "event_code": df_sudan["EventCode"],
        "event_base_code": df_sudan["EventBaseCode"],
        "event_root_code": df_sudan["EventRootCode"],
        "event_description": df_sudan["event_description"],
        "cameo_bucket": df_sudan["cameo_bucket"],
        "quad_class": df_sudan["QuadClass"],
        "goldstein_scale": df_sudan["GoldsteinScale"],
        "num_mentions": df_sudan["NumMentions"],
        "num_sources": df_sudan["NumSources"],
        "num_articles": df_sudan["NumArticles"],
        "avg_tone": df_sudan["AvgTone"],
        "action_geo_name": df_sudan["ActionGeo_FullName"],
        "action_geo_lat": df_sudan["ActionGeo_Lat"],
        "action_geo_long": df_sudan["ActionGeo_Long"],
        "action_geo_country": df_sudan["ActionGeo_CountryCode"],
        "source_url": df_sudan["SOURCEURL"],
        "date_added": df_sudan["DATEADDED"],
    })

    # Insert into SQLite
    conn = sqlite3.connect(settings.DATABASE_PATH)

    # "OR IGNORE" skips rows whose global_event_id already exists
    columns = list(events_df.columns)
    placeholders = ", ".join(["?"] * len(columns))
    col_names = ", ".join(columns)
    sql = f"INSERT OR IGNORE INTO events ({col_names}) VALUES ({placeholders})"

    for _, row in events_df.iterrows():
        conn.execute(sql, tuple(row))

    # Update actors and locations tables
    update_actors(conn, events_df)
    update_locations(conn, events_df)

    conn.commit()
    conn.close()

    rows_stored = len(events_df)
    log_ingestion(file_url, len(df), rows_stored)
    print(f"Stored {rows_stored} Sudan events from {file_url}")
    return rows_stored

def update_actors(conn: sqlite3.Connection, events_df: pd.DataFrame):
    """Insert or update unique actors from the latest batch of events."""
    for actor_col, country_col, type_col in [
        ("actor1_name", "actor1_country_code", "actor1_type"),
        ("actor2_name", "actor2_country_code", "actor2_type"),
    ]:
        actors = events_df[[actor_col, country_col, type_col, "event_date"]].dropna(subset=[actor_col])
        for _, row in actors.iterrows():
            conn.execute("""
                INSERT INTO actors (name, country_code, actor_type, first_seen, last_seen, event_count)
                VALUES (?, ?, ?, ?, ?, 1)
                ON CONFLICT(name) DO UPDATE SET
                    last_seen = MAX(last_seen, excluded.last_seen),
                    event_count = event_count + 1
            """, (row[actor_col], row[country_col], row[type_col], row["event_date"], row["event_date"]))


def update_locations(conn: sqlite3.Connection, events_df: pd.DataFrame):
    """Insert or update unique locations from the latest batch of events."""
    locs = events_df[["action_geo_name", "action_geo_lat", "action_geo_long", "action_geo_country"]].dropna(subset=["action_geo_name"])
    for _, row in locs.iterrows():
        conn.execute("""
            INSERT INTO locations (name, latitude, longitude, country_code, event_count)
            VALUES (?, ?, ?, ?, 1)
            ON CONFLICT(name, latitude, longitude) DO UPDATE SET
                event_count = event_count + 1
        """, (row["action_geo_name"], row["action_geo_lat"], row["action_geo_long"], row["action_geo_country"]))


def log_ingestion(file_url: str, rows_fetched: int, rows_stored: int):
    """Record this download in the ingestion_log table."""
    try:
        conn = sqlite3.connect(settings.DATABASE_PATH)
        conn.execute(
            "INSERT OR IGNORE INTO ingestion_log (file_url, rows_fetched, rows_stored) VALUES (?, ?, ?)",
            (file_url, rows_fetched, rows_stored),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Failed to log ingestion: {e}")


# Quick test: fetch the latest file and process it
if __name__ == "__main__":
    from ingestion.gdelt_fetcher import fetch_latest

    print("Fetching latest GDELT data...")
    csv_text, url = fetch_latest()
    if csv_text:
        rows = process_csv(csv_text, url)
        print(f"\nDone. {rows} Sudan-related events stored in database.")

        # Show a sample of what's in the database now
        conn = sqlite3.connect(settings.DATABASE_PATH)
        cursor = conn.execute("SELECT COUNT(*) FROM events")
        print(f"Total events in database: {cursor.fetchone()[0]}")
        cursor = conn.execute("SELECT DISTINCT name FROM actors LIMIT 10")
        print(f"Sample actors: {[r[0] for r in cursor.fetchall()]}")
        cursor = conn.execute("SELECT DISTINCT name FROM locations LIMIT 10")
        print(f"Sample locations: {[r[0] for r in cursor.fetchall()]}")
        conn.close()
    else:
        print("No data fetched.")