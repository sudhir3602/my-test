"""
config.py is the Central configuration for this project.

This file reads settings from the .env file in the project root
and makes them available to every other file in the backend.

HOW IT WORKS:
1. python-dotenv reads the .env file and loads key=value pairs
2. We store each setting in a simple class called Settings
3. Any file that needs a setting does: from config import settings
"""

import os
from dotenv import load_dotenv

# Loading the .env file
load_dotenv(override=False)


# Defining a Settings class 
class Settings:
    """All configuration values for the Anchor backend."""

    # LLM Settings
    ANCHOR_MODEL: str = os.getenv("ANCHOR_MODEL", "sqlcoder:7b")

    # Port Settings
    OLLAMA_HOST: str = os.getenv("OLLAMA_HOST", "http://localhost:11434")

    # Database Settings
    DATABASE_PATH: str = os.getenv("DATABASE_PATH", "./data/anchor.db")

    # GDELT Settings
    GDELT_UPDATE_INTERVAL: int = int(os.getenv("GDELT_UPDATE_INTERVAL", "15"))

    # Frontend Settings
    FRONTEND_URL: str = os.getenv("FRONTEND_URL", "http://localhost:5173")


# Creating one global instance
settings = Settings()


# Sanity check
if __name__ == "__main__":
    print("Current Configuration")
    print(f"  ANCHOR_MODEL:          {settings.ANCHOR_MODEL}")
    print(f"  OLLAMA_HOST:           {settings.OLLAMA_HOST}")
    print(f"  DATABASE_PATH:         {settings.DATABASE_PATH}")
    print(f"  GDELT_UPDATE_INTERVAL: {settings.GDELT_UPDATE_INTERVAL} minutes")
    print(f"  FRONTEND_URL:          {settings.FRONTEND_URL}")
    print("Done!")