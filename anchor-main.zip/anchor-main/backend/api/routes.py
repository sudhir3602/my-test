"""
routes.py

All API endpoints for the Anchor backend.

  GET  /api/health  — Is the server running? How much data do we have?
  GET  /api/stats   — Database summary for the admin panel.
  POST /api/query   — Accept analyst question, LLM generates SQL, return chart data.
"""

import time
import sqlite3
from fastapi import APIRouter, HTTPException

import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config import settings
from database.db import get_connection
from api.schemas import QueryRequest, QueryResponse, HealthResponse, StatsResponse, PinRequest
from utils.sql_validator import validate_sql
from utils.logger import get_logger
from llm.prompt_templates import get_system_prompt, build_user_prompt, infer_chart_type
from llm.ollama_client import query_llm
from llm.response_parser import parse_llm_response

logger = get_logger(__name__)

router = APIRouter(prefix="/api")

# Store conversation history in memory (per conversation_id)
conversations: dict[str, list] = {}


@router.get("/health", response_model=HealthResponse)
def health_check():
    """Basic status check."""
    conn = get_connection()
    try:
        count = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        latest = conn.execute("SELECT MAX(event_date) FROM events").fetchone()[0]

        return HealthResponse(
            status="healthy",
            model=settings.ANCHOR_MODEL,
            database_path=settings.DATABASE_PATH,
            total_events=count,
            latest_event_date=latest,
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return HealthResponse(
            status="error",
            model=settings.ANCHOR_MODEL,
            database_path=settings.DATABASE_PATH,
            total_events=0,
        )
    finally:
        conn.close()


@router.get("/stats", response_model=StatsResponse)
def get_stats():
    """Database summary for the admin panel."""
    conn = get_connection()
    try:
        total_events = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]
        total_actors = conn.execute("SELECT COUNT(*) FROM actors").fetchone()[0]
        total_locations = conn.execute("SELECT COUNT(*) FROM locations").fetchone()[0]

        date_range_row = conn.execute(
            "SELECT MIN(event_date), MAX(event_date) FROM events"
        ).fetchone()
        date_range = {"earliest": date_range_row[0], "latest": date_range_row[1]}

        top_actors = [
            {"name": r[0], "count": r[1]}
            for r in conn.execute(
                "SELECT name, event_count FROM actors ORDER BY event_count DESC LIMIT 10"
            ).fetchall()
        ]

        top_locations = [
            {"name": r[0], "count": r[1]}
            for r in conn.execute(
                "SELECT name, event_count FROM locations ORDER BY event_count DESC LIMIT 10"
            ).fetchall()
        ]

        events_by_bucket = [
            {"bucket": r[0], "count": r[1]}
            for r in conn.execute(
                "SELECT cameo_bucket, COUNT(*) as c FROM events GROUP BY cameo_bucket ORDER BY c DESC"
            ).fetchall()
        ]

        return StatsResponse(
            total_events=total_events,
            total_actors=total_actors,
            total_locations=total_locations,
            date_range=date_range,
            top_actors=top_actors,
            top_locations=top_locations,
            events_by_bucket=events_by_bucket,
        )
    except Exception as e:
        logger.error(f"Stats query failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        conn.close()


@router.post("/query", response_model=QueryResponse)
def run_query(request: QueryRequest):
    """Process an analyst question through the full LLM pipeline.

    Flow: user question -> LLM generates SQL -> validate -> execute -> infer chart -> return
    """
    start_time = time.time()

    # Step 1: Get conversation history for follow-ups
    history = conversations.get(request.conversation_id, []) if request.conversation_id else []

    # Step 2: Build the full prompt in SQLCoder's exact training format
    full_prompt = build_user_prompt(request.query, history if history else None)

    # Step 3: Send to LLM (full prompt goes as one string)
    llm_result = query_llm(full_prompt, "")

    if llm_result["error"]:
        return QueryResponse(
            query=request.query,
            sql_generated="",
            chart_type="error",
            chart_config={},
            data=[],
            error=llm_result["error"],
            response_time_ms=int((time.time() - start_time) * 1000),
        )

    # Step 4: Extract SQL from the LLM's response
    parsed = parse_llm_response(llm_result["text"])

    if parsed["parse_error"]:
        logger.warning(f"LLM raw output: {llm_result['text'][:300]}")
        return QueryResponse(
            query=request.query,
            sql_generated="",
            chart_type="error",
            chart_config={},
            data=[],
            error=f"Could not extract SQL from LLM response",
            response_time_ms=int((time.time() - start_time) * 1000),
        )

    # Step 5: Validate the SQL (security gate)
    validation = validate_sql(parsed["sql"])

    if not validation["valid"]:
        logger.warning(f"LLM generated invalid SQL: {validation['error']}")
        return QueryResponse(
            query=request.query,
            sql_generated=parsed["sql"],
            chart_type="error",
            chart_config={},
            data=[],
            error=f"Generated SQL was rejected: {validation['error']}",
            response_time_ms=int((time.time() - start_time) * 1000),
        )

    sql = validation["cleaned_sql"]

    # Step 6: Execute the validated SQL
    conn = get_connection()
    try:
        sql_start = time.time()
        cursor = conn.execute(sql)
        columns = [desc[0] for desc in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        sql_ms = int((time.time() - sql_start) * 1000)

        # Step 7: Infer chart type from the question and results
        chart_info = infer_chart_type(request.query, sql, columns)

        elapsed = int((time.time() - start_time) * 1000)
        logger.info(f"Query complete: {len(rows)} rows, {elapsed}ms total "
                     f"({llm_result['response_time_ms']}ms LLM, {sql_ms}ms SQL) "
                     f"-> {chart_info['chart_type']}")

        # Log to query_logs table
        conn.execute(
            """INSERT INTO query_logs
               (user_query, model_used, llm_response_ms, sql_generated, sql_valid,
                sql_execution_ms, rows_returned, chart_type, total_response_ms)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (request.query, settings.ANCHOR_MODEL, llm_result["response_time_ms"],
             sql, True, sql_ms, len(rows), chart_info["chart_type"], elapsed),
        )
        conn.commit()

        # Save to conversation history for follow-ups
        if request.conversation_id:
            if request.conversation_id not in conversations:
                conversations[request.conversation_id] = []
            conversations[request.conversation_id].append({
                "user": request.query,
                "sql": sql,
            })

        return QueryResponse(
            query=request.query,
            sql_generated=sql,
            chart_type=chart_info["chart_type"],
            chart_config={
                "title": chart_info["title"],
                "x_label": chart_info["x_label"],
                "y_label": chart_info["y_label"],
                "columns": columns,
            },
            data=rows,
            response_time_ms=elapsed,
        )

    except sqlite3.Error as e:
        elapsed = int((time.time() - start_time) * 1000)
        logger.error(f"SQL execution failed: {e}")

        conn.execute(
            """INSERT INTO query_logs
               (user_query, model_used, llm_response_ms, sql_generated, sql_valid,
                sql_execution_ms, rows_returned, chart_type, total_response_ms, error)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (request.query, settings.ANCHOR_MODEL, llm_result["response_time_ms"],
             sql, True, 0, 0, "error", elapsed, str(e)),
        )
        conn.commit()

        return QueryResponse(
            query=request.query,
            sql_generated=sql,
            chart_type="error",
            chart_config={},
            data=[],
            error=f"SQL error: {e}",
            response_time_ms=elapsed,
        )
    finally:
        conn.close()

@router.post("/pin")
def pin_chart(request: PinRequest):
    """Save a chart to the dashboard."""
    import json
    conn = get_connection()
    try:
        conn.execute(
            "INSERT INTO pinned_charts (title, sql_query, chart_type, chart_config) VALUES (?, ?, ?, ?)",
            (request.title, request.sql_query, request.chart_type, json.dumps(request.chart_config)),
        )
        conn.commit()
        logger.info(f"Pinned chart: {request.title}")
        return {"status": "ok", "message": f"Chart '{request.title}' pinned to dashboard"}
    finally:
        conn.close()


@router.get("/pinned")
def get_pinned_charts():
    """Fetch all pinned charts with refreshed data."""
    import json
    conn = get_connection()
    try:
        rows = conn.execute("SELECT * FROM pinned_charts ORDER BY pinned_at DESC").fetchall()
        results = []
        for row in rows:
            chart = {
                "id": row["id"],
                "title": row["title"],
                "sql_query": row["sql_query"],
                "chart_type": row["chart_type"],
                "chart_config": json.loads(row["chart_config"] or "{}"),
                "pinned_at": row["pinned_at"],
                "data": [],
            }
            # Re-run the saved SQL to get fresh data
            try:
                cursor = conn.execute(row["sql_query"])
                columns = [desc[0] for desc in cursor.description]
                chart["data"] = [dict(zip(columns, r)) for r in cursor.fetchall()]
            except Exception as e:
                chart["data"] = []
                chart["error"] = str(e)
            results.append(chart)
        return results
    finally:
        conn.close()


@router.delete("/pin/{chart_id}")
def unpin_chart(chart_id: int):
    """Remove a pinned chart."""
    conn = get_connection()
    try:
        conn.execute("DELETE FROM pinned_charts WHERE id = ?", (chart_id,))
        conn.commit()
        return {"status": "ok"}
    finally:
        conn.close()

@router.get("/settings/actor-config")
def get_actor_config():
    """Return the current actor normalisation config."""
    import json
    config_path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "actor_config.json")
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="actor_config.json not found")


@router.put("/settings/actor-config")
def update_actor_config(config: dict):
    """Update the actor normalisation config.
    
    After saving, the next ingestion cycle will use the new mappings.
    To apply to existing data, re-run the ingestion pipeline.
    """
    import json
    config_path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "actor_config.json")

    required_keys = {"conflict_name", "country_codes", "filter_keywords", "actor_name_map", "location_actors"}
    if not required_keys.issubset(config.keys()):
        missing = required_keys - config.keys()
        raise HTTPException(status_code=400, detail=f"Missing required keys: {missing}")

    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        logger.info(f"Actor config updated: {len(config['actor_name_map'])} mappings")
        return {"status": "ok", "message": "Config saved. Re-run ingestion to apply to existing data."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/settings/reingest")
def trigger_reingest():
    """Delete the database and signal that re-ingestion is needed.
    
    Does not run the full backfill (that takes too long for an API call).
    Returns instructions for the operator.
    """
    return {
        "status": "ok",
        "message": "To apply config changes to existing data, run from backend/: "
                   "rm ../data/anchor.db && python -m database.db && "
                   "python -m ingestion.run_ingestion backfill 2023-04-15 2026-04-08",
    }

@router.post("/sql")
def run_raw_sql(request: QueryRequest):
    """Execute raw SQL directly, bypassing the LLM. For internal frontend components."""
    validation = validate_sql(request.query)
    if not validation["valid"]:
        return {"data": [], "error": validation["error"]}

    conn = get_connection()
    try:
        cursor = conn.execute(validation["cleaned_sql"])
        columns = [desc[0] for desc in cursor.description]
        rows = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return {"data": rows, "columns": columns, "error": None}
    except sqlite3.Error as e:
        return {"data": [], "error": str(e)}
    finally:
        conn.close()

@router.get("/settings/prompt")
def get_prompt():
    """Return only the editable portion of the prompt (without few-shot examples)."""
    from llm.prompt_templates import build_full_prompt
    full = build_full_prompt("SAMPLE_QUESTION")
    # Cut everything from the examples section onward
    marker = "Here are example question-and-SQL pairs"
    idx = full.find(marker)
    if idx > 0:
        return {"prompt": full[:idx].strip()}
    return {"prompt": full}


@router.put("/settings/prompt")
def update_prompt(body: dict):
    """Save a custom system prompt override."""
    import json
    prompt_path = os.path.join(os.path.dirname(__file__), "..", "..", "data", "custom_prompt.txt")
    try:
        with open(prompt_path, "w", encoding="utf-8") as f:
            f.write(body.get("prompt", ""))
        logger.info("Custom prompt saved")
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/settings/models")
def get_models():
    """List available Ollama models."""
    from llm.ollama_client import check_ollama_status
    status = check_ollama_status()
    return {"current": settings.ANCHOR_MODEL, "available": status.get("available_models", [])}


@router.put("/settings/model")
def switch_model(body: dict):
    """Switch the active model."""
    new_model = body.get("model", "")
    if not new_model:
        raise HTTPException(status_code=400, detail="No model specified")
    settings.ANCHOR_MODEL = new_model
    logger.info(f"Model switched to: {new_model}")
    return {"status": "ok", "model": new_model}

@router.post("/settings/backfill")
def trigger_backfill():
    """Start a backfill from the last ingested date to now, in a background thread."""
    import threading
    from datetime import datetime, timedelta

    conn = get_connection()
    try:
        row = conn.execute("SELECT MAX(event_date) FROM events").fetchone()
        last_date = row[0] if row[0] else "2023-04-15"
    finally:
        conn.close()

    # Start from the day after the last event
    start = (datetime.strptime(last_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
    end = datetime.now().strftime("%Y-%m-%d")

    if start >= end:
        return {"status": "ok", "message": "Already up to date."}

    def run_backfill():
        from ingestion.gdelt_fetcher import fetch_historical
        from ingestion.gdelt_processor import process_csv
        results = fetch_historical(start, end)
        total = 0
        for csv_text, url in results:
            total += process_csv(csv_text, url)
        logger.info(f"Backfill complete: {total} events from {start} to {end}")

    thread = threading.Thread(target=run_backfill, daemon=True)
    thread.start()
    logger.info(f"Backfill started in background: {start} to {end}")

    return {"status": "ok", "message": f"Backfill started from {start} to {end}. This runs in the background."}


@router.put("/settings/update-interval")
def set_update_interval(body: dict):
    """Change how frequently GDELT data is pulled."""
    minutes = body.get("minutes")
    if not minutes or not isinstance(minutes, (int, float)) or minutes < 1:
        raise HTTPException(status_code=400, detail="Invalid interval")
    settings.GDELT_UPDATE_INTERVAL = int(minutes)
    logger.info(f"Update interval changed to {minutes} minutes")
    return {"status": "ok", "minutes": int(minutes)}


@router.get("/settings/update-interval")
def get_update_interval():
    """Get the current GDELT update interval."""
    return {"minutes": settings.GDELT_UPDATE_INTERVAL}