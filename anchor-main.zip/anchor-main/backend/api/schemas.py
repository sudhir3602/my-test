"""
schemas.py

Defines the shape of every request and response in the API.
Pydantic validates incoming data automatically — if the frontend
sends a query without the required fields, FastAPI returns a
clear error before our code even runs.
"""

from pydantic import BaseModel
from typing import Optional


# -- Requests (what the frontend sends to us) --

class QueryRequest(BaseModel):
    """What the analyst sends when they type a question."""
    query: str
    # Conversation history so the LLM can handle follow-ups like "now compare with SAF"
    conversation_id: Optional[str] = None


class BackfillRequest(BaseModel):
    """Trigger a historical data download from the admin panel."""
    start_date: str
    end_date: str


# -- Responses (what we send back to the frontend) --

class QueryResponse(BaseModel):
    """The full response to an analyst query."""
    query: str
    sql_generated: str
    chart_type: str
    chart_config: dict
    data: list
    error: Optional[str] = None
    response_time_ms: int


class HealthResponse(BaseModel):
    """Basic health check for monitoring."""
    status: str
    model: str
    database_path: str
    total_events: int
    latest_event_date: Optional[str] = None


class StatsResponse(BaseModel):
    """Database statistics for the admin panel."""
    total_events: int
    total_actors: int
    total_locations: int
    date_range: dict
    top_actors: list
    top_locations: list
    events_by_bucket: list

class PinRequest(BaseModel):
    """Save a chart to the dashboard."""
    title: str
    sql_query: str
    chart_type: str
    chart_config: dict = {}


class PinnedChart(BaseModel):
    """A saved chart returned from the database."""
    id: int
    title: str
    sql_query: str
    chart_type: str
    chart_config: dict
    pinned_at: str
    data: list = []

if __name__ == "__main__":
    # Quick test — create a sample response to make sure the schema works
    sample = QueryResponse(
        query="Show RSF activity over time",
        sql_generated="SELECT event_date, COUNT(*) FROM events WHERE actor1_name='RSF' GROUP BY event_date",
        chart_type="line",
        chart_config={"x_label": "Date", "y_label": "Event Count", "title": "RSF Activity"},
        data=[{"date": "2023-04-15", "count": 45}, {"date": "2023-04-16", "count": 72}],
        response_time_ms=230,
    )
    print("Sample QueryResponse:")
    print(sample.model_dump_json(indent=2))