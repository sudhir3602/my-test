# Project Anchor

An intelligence dashboard for monitoring evolving international situations.

## Overview

Anchor ingests structured event data from GDELT, processes it into actionable signals,
and presents them through an interactive dashboard powered by a local LLM running on
NVIDIA Jetson Orin Nano.

## Tech Stack

- **Backend:** Python 3.12, FastAPI, SQLite
- **Frontend:** React 18, TypeScript, Tailwind CSS, Recharts, React-Leaflet
- **LLM Runtime:** Ollama
- **LLM Models:** SQLCoder-7B-2 (primary), Phi-3.5 Mini (fallback), Llama 3.2 3B (fallback)
- **Data Source:** GDELT (Global Database of Events, Language, and Tone)
- **Deployment:** Docker, NVIDIA Jetson Orin Nano (8GB)

## Team

Rohit Ritesh Maini.
Sahil Gangadia
Timothy Peter
